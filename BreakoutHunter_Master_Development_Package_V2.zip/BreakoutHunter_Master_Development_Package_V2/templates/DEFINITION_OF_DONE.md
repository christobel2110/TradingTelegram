# Task Definition of Done

- [ ] Task ID + requirement references godkjent.
- [ ] Allowed exact files/worktree/branch eies eksklusivt.
- [ ] Implementation og negative cases ferdig; ingen live ordrefunksjonalitet.
- [ ] Targeted pytest PASS; full CI PASS.
- [ ] 100% statement, 100% branch **separate counts** per critical production package.
- [ ] Typecheck/lint/formatter/security/dependency/secret scan PASS.
- [ ] Contract + integration/fault/perf tests PASS som relevant.
- [ ] Critical HIGH reviewed by distinct reviewer.
- [ ] Evidence manifest knyttet til exact git SHA; no stale checks.
- [ ] Kontrakter, docs, progress, changelog oppdatert.
- [ ] Phase acceptance PASS; bruker-GO kreves for neste fase.
