# PHASE 12: Research Kernel & Backtesting

**Mål:** Autonomous bounded research within approved scope.

**Inngang:** Fase 11 godkjent med faktisk CI-evidence og GO.

**Relevant kildesteg:** BH-REQ-008, BH-REQ-009, BH-REQ-040, BH-REQ-057, BH-REQ-058

## Ferdigdefinerte kodeoppgaver (kan fordeles mellom 2 agenter)

### BH-12-01 — Implement preregistered experiment registry
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Data version hash, params, baseline, hypothesis.

**Negativt akseptansekriterium:** All trials logged including losers.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/research/implement_preregistered_experiment_regis*`, `backend/tests/research/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-12-02 — Implement deterministic event backtest runner
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** No future data and timestamp-causal fills.

**Negativt akseptansekriterium:** Golden replay exactly repeats.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/research/implement_deterministic_event_backtest_r*`, `backend/tests/research/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-12-03 — Implement realistic execution cost adapters
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Spread slippage funding and partial fills per market.

**Negativt akseptansekriterium:** Compare cost stress with paper results.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/research/implement_realistic_execution_cost_adapt*`, `backend/tests/research/*`.

**Avhengigheter:** BH-12-01.

### BH-12-04 — Implement walk-forward/purged split factory
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Chronological train/val/OOS and overlap embargo.

**Negativt akseptansekriterium:** Overlapping labels absent across splits.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/research/implement_walk_forward_purged_split_fact*`, `backend/tests/research/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-12-05 — Implement bounded experiment search
**Forslag eier:** agent_a · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** Budgeted random/guided, dedup fingerprint and seed.

**Negativt akseptansekriterium:** No unlimited parameter search.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/research/implement_bounded_experiment_search*`, `backend/tests/research/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-12-06 — Profile selective Numba acceleration
**Forslag eier:** agent_b · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** Bench baseline vs JIT only if gains proven.

**Negativt akseptansekriterium:** Same numerical outputs incl cold-start.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/research/profile_selective_numba_acceleration*`, `backend/tests/research/*`.

**Avhengigheter:** BH-12-01.

### BH-12-07 — Implement research priority/pause/checkpoints
**Forslag eier:** agent_a · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** No more than 1 heavy job on target, safe resume.

**Negativt akseptansekriterium:** Research pause does not impact scanner.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/research/implement_research_priority_pause_checkp*`, `backend/tests/research/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-12-08 — Phase 12 research baseline acceptance
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Fixed fixture multiple coins with negative trials.

**Negativt akseptansekriterium:** No statement of validated edge.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/research/phase_12_research_baseline_acceptance*`, `backend/tests/research/*`.

**Avhengigheter:** BH-12-01, BH-12-02, BH-12-03, BH-12-04, BH-12-05, BH-12-06, BH-12-07.

## Exit Gate
- Alle tasks PASS på eksakt merge commit.
- Statement og branch coverage kontrollert separat.
- Kritiske negative scenariotester, security scan og evt Windows mål-PC tester PASS.
- Release/testevidence og dokumentasjon oppdatert.
- Bruker GO før neste fase.
