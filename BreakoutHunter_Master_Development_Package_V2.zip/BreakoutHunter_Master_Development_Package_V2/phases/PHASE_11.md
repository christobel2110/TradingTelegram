# PHASE 11: Read-only GPT Gateway & Research Inbox

**Mål:** Custom GPT analysis without privileged control.

**Inngang:** Fase 10 godkjent med faktisk CI-evidence og GO.

**Relevant kildesteg:** BH-REQ-020, BH-REQ-033, BH-REQ-034

## Ferdigdefinerte kodeoppgaver (kan fordeles mellom 2 agenter)

### BH-11-01 — Implement read models for signals/evidence
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D3_Critical

**Leveranse:** Stable paginated GET summaries with UTC/source/version.

**Negativt akseptansekriterium:** Do not query raw Market DB in expensive way.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/gateway/implement_read_models_for_signals_eviden*`, `backend/tests/gateway/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-11-02 — Implement bearer auth, ACL, rate limiting
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D3_Critical

**Leveranse:** Auth, TTL, response-size limits and audit IDs.

**Negativt akseptansekriterium:** Unauthorized requests never leak metadata.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/gateway/implement_bearer_auth_acl_rate_limiting*`, `backend/tests/gateway/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-11-03 — Implement GET-only OpenAPI endpoints
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Top/coin/regime/history/decision/risk/status.

**Negativt akseptansekriterium:** Any POST approval/trade returns 405/404.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/gateway/implement_get_only_openapi_endpoints*`, `backend/tests/gateway/*`.

**Avhengigheter:** BH-11-01.

### BH-11-04 — Design Cloudflare Tunnel TLS exposure policy
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D3_Critical

**Leveranse:** Separate limited public gateway from private dashboard.

**Negativt akseptansekriterium:** Tunnel alone not counted as authentication.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/gateway/design_cloudflare_tunnel_tls_exposure_po*`, `backend/tests/gateway/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-11-05 — Prepare Custom GPT instructions and evals
**Forslag eier:** agent_a · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** Evidence-first, freshness, NO TRADE, review rules.

**Negativt akseptansekriterium:** No price hallucinations on unavailable gateway.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/gateway/prepare_custom_gpt_instructions_and_eval*`, `backend/tests/gateway/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-11-06 — Implement Strategy Decision Inbox read API
**Forslag eier:** agent_b · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** Research Decision Packet L1/L2 with IDs.

**Negativt akseptansekriterium:** GPT action cannot mutate status.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/gateway/implement_strategy_decision_inbox_read_a*`, `backend/tests/gateway/*`.

**Avhengigheter:** BH-11-01.

### BH-11-07 — Phase 11 attack & latency audit
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Fuzz path/query/oversize and stale data.

**Negativt akseptansekriterium:** Gateway latency cannot starve scanner.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/gateway/phase_11_attack_latency_audit*`, `backend/tests/gateway/*`.

**Avhengigheter:** BH-11-01, BH-11-02, BH-11-03, BH-11-04, BH-11-05, BH-11-06.

## Exit Gate
- Alle tasks PASS på eksakt merge commit.
- Statement og branch coverage kontrollert separat.
- Kritiske negative scenariotester, security scan og evt Windows mål-PC tester PASS.
- Release/testevidence og dokumentasjon oppdatert.
- Bruker GO før neste fase.
