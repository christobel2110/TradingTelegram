# Release Readiness / Godkjenning for første Windows-installasjon

Dette er sjekklisten, ikke en bekreftelse på at den er oppfylt.

- [ ] 91 trace records; step 91 resolved or deliberately deferred with ADR.
- [ ] All P0/required P1 implementation tasks PASS at exact commit with CI + enforced branch protection.
- [ ] Windows hardening verified on actual OS edition and target RTX driver.
- [ ] Scanner independent of AI/Research; read-only BingX, zero live order pathways.
- [ ] Freshness/gap/out-of-order and no-look-ahead tests PASS.
- [ ] Deterministic risk, stop math, paper partial fills, cross-strategy stress tests PASS.
- [ ] 100% statements and 100% branches independently in critical source + security scans.
- [ ] Model Qwen/local runtime + CPU fallback tested; resource guard under normal desktop activity.
- [ ] API token reservation tested with concurrent calls and unavailable model states.
- [ ] External GPT Gateway auth/rate limit/provenance tested; no admin/control routes.
- [ ] Installer on dedicated disk from clean Windows, no global dev tool requirement.
- [ ] Signatures on application and model; backup off-host tested and restore on clean disk.
- [ ] Update safe activation + rollback, including DB compatibility safety.
- [ ] Command Center and Telegram show offline/stale on system shutdown.
- [ ] Privacy: no keys/PII in code, analytics, logs or output.
- [ ] User signoff and known-good release SHA archived.
