#!/usr/bin/env python3
"""Verify 1..91 trace and backlogged tasks; does not test production implementation."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
reg=json.loads((ROOT/'requirements/requirements_registry.json').read_text(encoding='utf-8'))['items']
tasks=json.loads((ROOT/'tasks/TASK_BACKLOG.json').read_text(encoding='utf-8'))['tasks']
assert [x['source_step'] for x in reg] == list(range(1,92))
assert reg[-1]['decision_status']=='PROPOSED_NOT_APPROVED'
ids={t['task_id'] for t in tasks}
assert len(ids)==len(tasks)
assert all(all(d in ids for d in t['depends_on']) for t in tasks)
assert all(t['phase_prerequisite'] for t in tasks)
assert all(t['acceptance_criteria'] and t['test_plan'] for t in tasks)
print(f'REGISTRY OK: {len(reg)} trace rows; {len(tasks)} unstarted development tasks')
