# System Architecture — modulær monolitt med isolerte prosesser

## Runtime topologi
1. **Scanner Core (kritisk prosess):** BingX public market streams, discovery, candle-validator, incremental indicatorer, SMC, regime, signal-state, risk eligibility og journal. Ingen import/await av LLM eller Research i hot path.
2. **Intelligence Worker (lavere prioritet):** Portable llama.cpp, local adapter, OpenAI API adapter, kontekst, budget/caching. 1 inferens lokalt; bounded queue, drop/expire *noncritical analysis requests*, aldri ferdige kritiske signaler.
3. **Research Worker (lav prioritet, isolert):** snapshots/Parquet, backtests, probability, drift, champion/challenger/shadow, governance forslag. Kan stoppes uten signal- eller datatap.
4. **I/O Interface (lett):** FastAPI Read model / Telegram outbox / Command Center. GPT Gateway er et smalt read-only API-snitt, ikke direkte databaseadministrasjon.
5. **Supervisor (lett):** health, audit, startup gates, process restart budget/backoff/quarantine. Update/install/backup er jobber, ikke 24/7 LLM-agenter.

## Logisk modulgruppering
`core`, `market_data`, `data_platform`, `indicators`, `market_structure`, `opportunity`, `risk`, `paper`, `ai`, `research`, `knowledge`, `governance`, `interface`, `operations`.
Kontraktene er overført som immutable/versioned DTOer. Bruk domain interfaces, ikke kryssimporter intern implementasjon. Unngå mikroservice-kompleksitet på 16GB PC.

## Kritisk dataflyt
BingX WebSocket/REST -> normalize -> validate sequence/completeness -> append event journal transaction -> incremental calculations -> deterministic gating -> signal event transaction -> outbox -> notifier / AI router. Event IDs bygges stabilt fra market, symbol, timeframe, candle close/open, strategy_version, signal_type og snapshot hash. **Exactly-once delivery over nettverket kan ikke garanteres**; bruk *at-least-once* leveranse + idempotency keys og reconciliation.

## Storage
- `market.db` (SQLite WAL): aktive candles, event journal, signal- og paper-state, outbox, market integrity flags.
- `research.db` (SQLite WAL): hypoteser, experiment IDs, provenance og validation metadata; synkroniser via watermark + idempotent import. Kan være ute av drift uten at scanner stopper.
- Parquet/ZSTD for historiske candles og store forskningsdatasett; manifest med checksum og dataversjon. Ikke delmutable forskningssnapshots med scanner.
- Admin approval/audit kan logisk ligge i beskyttede tabeller i market DB eller egen append-only auditfil; det skal ikke være avhengig av Research DB.

## Tidsregler
All intern tid i UTC med tidssoneindikerte ISO-8601-stringer eller Unix ms. `observed_at` (marked), `ingested_at` (system), `generated_at` (signal), `available_as_of` (for ML research). Candles må merkes `is_closed`; ingen confirm basert på endelig candle før lukket. Futures/Spot skilles på instrument ID og aldri merges implisitt.

## Failure-isolation
- Manglende/foreldede markedsdata: avvis nye berørte signaler / `DATA_STALE`.
- Research invalid: pause forskning; fortsatt scanner.
- LLM nede eller under minnepress: regelbasert signal med AI=SKIPPED; ingen forsinkelse.
- Telegram timeout: durable outbox + retry; ikke dupliser signaler.
- Disk/market journal ikke skrivbar: fail closed for nye signaler, ikke bare logg og fortsett.
- PC avslått: ingen live scanning; innhent historiske candles ved omstart, men *ikke* rekonstruer «observerte» live-fills.

## Ports og nettverk
Scanner har utgående offentlig BingX markedsdata; separat AI API/Telegram når aktivert. Llama server bindes til loopback og skal ikke ha egne utgående tillatelser. Dashboard bindes loopback; ekstern mobil via privat Tailscale/VPN med applikasjonsauth. Ekstern GPT Actions via herdet read-only HTTPS Gateway med eksplisitt auth; ingen offentlig administrasjon.

## Beslutningslogikk
Opportunity før sannsynlighet: deterministic Early/Readiness/Quality/Opportunity baseline, harde likviditets- og risikoavslag. Probability estimater kun Shadow til dokumentert OOS-kalibrering. Memory Influence kun etter validering + bruker-GO, ikke mer enn forhåndsgodkjent cap. LLM kan annotere/utfordre, aldri omskrive trigger, stop, pris eller absolutt risk gate.

## Ikke funksjonelt mål
P95 etter ferdig candle -> regelbasert signal <2 s på testunivers 100 instrumenter er **mål** som må benchmarkes på mål-PC. Scanner RAM <500MB og lav CPU er foreslått mål, ikke garantert. Slå av avanserte funksjoner ved ressurs-press.
