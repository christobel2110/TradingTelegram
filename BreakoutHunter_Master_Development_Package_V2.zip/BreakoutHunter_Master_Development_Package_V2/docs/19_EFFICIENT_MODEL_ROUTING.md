# Minimal-Usage Model Routing — development AND runtime

## First, route work to deterministic tools
Before any extra model call, ask: Can lint, Pyright, pytest, script, regex/schema checker, diff, SQLite/Parquet query or NumPy compute the answer? If yes, do that. Do not call LLM to compute indicators, calculate risk or approve a test.

## Development model profiles (recommendations, not claimed entitlements)
| Tier | Work | Criteria to use | Escalate when |
|---|---|---|---|
| D0 | inventory, formatting, schema, fixture regeneration | script first, smallest actually available model | deterministic checks reveal ambiguous semantics |
| D1 | one-file implementation, straightforward tests | cheap/fast qualified available model | nonlocal bug, security concern, repeated failure |
| D2 | concurrency, endpoint integration, data contracts | medium/high available model with proven eval | security boundary or data loss found |
| D3 | risk maths, auth, update signing, DB crash recovery | strongest *available* reviewed model and independent review | never downgrade just to save tokens |

### Routing is evidence-driven
1. Ask builder's model selector/telemetry for actual available model IDs and effort levels; if unknown leave `model_id=UNVERIFIED`, propose tier not a fabricated ID.
2. Assign every task `required_tier` (already in v2 backlog). Context pack contains task card, relevant schema, affected module/source, last failed test if applicable, no 91-step chat history.
3. Reuse deterministic test runs; no repeated model call on identical content hash.
4. Read shortened errors first, expand only targeted logs. Two identical failed fix attempts require new diagnosis, not same instruction.
5. Review HIGH changes independently; LOW changes rely on deterministic QA. Agent B's review uses diff + dependency surface not full re-reading.
6. At phase end log model/effort/token counts only if actually exposed. Evaluate **approved tasks/usage**, not raw task count.

## Runtime context thresholds
- `NO_AI` if deterministic or missing critical data.
- Local Qwen Q4 GGUF class initially 2–4B on shared RTX 8GB; benchmark exact model, actual context and worst-case VRAM; on-demand unload. Fallback NO_AI if CPU/GPU not healthy.
- OpenAI API for deadline-sensitive high-value/uncertain signals only when candidate fresh, budget reservation succeeds, model supported and independent evaluation adds value.
- Custom ChatGPT GPT is *interactive* reviewer: important strategy decisions routed to user + GPT through GET-only evidence packet, **not** automatically duplicated in runtime API costs.
- Critical numeric fields copied from schema-validated source, never model-generated numbers without independent check.

## Benchmarks
Same frozen dataset, same success criteria, compare correct decisions, missed critical risks, fact/JSON validity, p50/p95 latency, actual tokens/$ or GPU/RAM; analyze ablations (Python only vs Python+Qwen vs Python+GPT). Request caching is conditional, no guaranteed price discount or usage saving.

## Bounded budgets
Implement cost `reserve -> call -> reconcile` in durable transaction and separate `live`/`research` buckets; unknown model pricing or missing billing record => fail-closed paid call. Context compression may not drop financial/security info; prove quality on independent dataset before activation.
