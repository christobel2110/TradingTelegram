# Threat Model — Windows sandbox, API, secrets, recovery

## Trust boundaries
1. Internett/BingX-feeds: ubetrodde pris-/ordrebokpayloads, skjemavalidering, reconnect/gap, storm og rate-limit.
2. Local app under ikke-admin konto: ingen OS-control direkte fra modell. Dedikert disk er **ikke** en sandbox. ACL, service SID/egen konto, Windows Defender Firewall allowlist, Job Objects og prosessgrenser må konfigureres/testes.
3. Portable LLM binærfiler/modeller: approved registry, kryptografisk signert manifest, SHA-256, kjent opphav, lisens, no arbitrary download/execution.
4. OpenAI API: eksplisitt budsjett; minimal evidens uten private nøkler, intern metadata/sensitive data filtrert.
5. Ekstern GPT Actions: HTTPS public endpoint har **angrepsflate** også via Cloudflare Tunnel; verifiser Bearer/API-key, rate limits, deny-by-default, GET-only + no file/path/broker routes; admin kontrollrom forblir privat.
6. Telegram: autoriserte chat IDs + signert/validert interaksjon der relevant; aldri privilegert task execution.
7. Research: ubetrodde hypoteser og resultater; begrenset fs, CPU, RAM og nettverk; ingen prod DB writer eller live order capability.
8. Installer/updater: bootstrap signatur/root trust, nøkler utenfor installasjonsdisk, UAC for privilegert engangskonfigurasjon, user consent for credentials/network public endpoints.

## Harde sikkerhetstiltak
- Ingen private BingX-endepunkter eller ordreklient i v1. Automated negative tests søk etter forbidden methods/routes; wire egress block tests for order URLs.
- En særskilt konto for bakgrunnsdrift med tilgang til dedikerte appmapper, ikke hele brukerprofilen. Administrator kun ved installasjon/systemconfig.
- Windows ACL og firewall **må** valideres mot faktisk Windows-versjon. GPU VRAM har ingen garantert tilsvarende Job Object hard-limit; monitor/fail-safe.
- Secrets Windows DPAPI/Credential Manager der passende; krypterte offsite-backups med separat gjenopprettingsnøkkel. Ingen `.env` secrets i repo, logg eller zip.
- Installer kan ikke «automatisk» skape Telegram Bot/OAuth/API keys. Den ber om legitimasjon via lokal veiviser og eksplisitt samtykke.
- Rate limit/timing anomalies -> `REJECTED/STALE` status. Parse bounded payloads; no shell interpolation from market data.
- Sårbarhetskontroll av dependencies/signaturer, låste versjoner fra godkjente kilder; avvis manipulert modell/release.
- Nettverksbarriere: TLS verifisering; offentlig GPT gateway svarer bare autorisert, begrenset datamengde, aldri hemmeligheter eller filbaner.

## Security acceptancetests
`SEC-001`: no live order client/egress under normal runtime; `SEC-002`: crafted API payload no path traversal/code execution; `SEC-003`: unauthorized gateway 401/403; `SEC-004`: stale data fail closed; `SEC-005`: model cannot access market-db write interface; `SEC-006`: compromised update blocked by invalid signature; `SEC-007`: secrets absent in JSONL/traces; `SEC-008`: lost backup key reported, never unencrypted fallback; `SEC-009`: service cannot read other user data; `SEC-010`: compromised Research worker cannot mutate critical Market DB.

## Åpne verifikasjoner
Windows service account hardening, sandbox/network controls og GPU-driver-kompatibilitet er produkt-/edition-avhengig; implementatør må verifisere og dokumentere faktisk utført test. Ingen påstand om sterk VM-isolasjon.
