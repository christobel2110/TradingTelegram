# PHASE 06: Indicators, SMC & Regime

**Mål:** Deterministic multi-timeframe market intelligence.

**Inngang:** Fase 05 godkjent med faktisk CI-evidence og GO.

**Relevant kildesteg:** BH-REQ-006, BH-REQ-012, BH-REQ-064

## Ferdigdefinerte kodeoppgaver (kan fordeles mellom 2 agenter)

### BH-06-01 — Implement RSI MACD ATR and RVOL
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Fixed formulas warmup and reference fixtures.

**Negativt akseptansekriterium:** No current unfinished bar as closed.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/market_intelligence/implement_rsi_macd_atr_and_rvol*`, `backend/tests/market_intelligence/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-06-02 — Implement Bollinger compression and volume context
**Forslag eier:** agent_b · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** Squeeze and volume changes with explicit params.

**Negativt akseptansekriterium:** Stable under missing and zero volume.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/market_intelligence/implement_bollinger_compression_and_volu*`, `backend/tests/market_intelligence/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-06-03 — Implement confirmed swing and Fibonacci engine
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Macro/meso/micro confirmed swings; Golden Zone and extensions.

**Negativt akseptansekriterium:** No repaint after swing confirmation.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/market_intelligence/implement_confirmed_swing_and_fibonacci_*`, `backend/tests/market_intelligence/*`.

**Avhengigheter:** BH-06-01.

### BH-06-04 — Implement BOS CHoCH sweep/FVG/OB structures
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Event IDs, reclaim and dedupe with objective definitions.

**Negativt akseptansekriterium:** No look-ahead in pivot/structure detection.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/market_intelligence/implement_bos_choch_sweep_fvg_ob_structu*`, `backend/tests/market_intelligence/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-06-05 — Implement trend/stress regime state machine
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Bull/bear/range + vol stress/mixed/unknown; hysteresis.

**Negativt akseptansekriterium:** No flip-flop from single noisy candle.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/market_intelligence/implement_trend_stress_regime_state_mach*`, `backend/tests/market_intelligence/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-06-06 — Implement MTF alignment and BTC market filter
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** As-of timeframe joins and context evidence.

**Negativt akseptansekriterium:** Higher timeframe future candle never leaks.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/market_intelligence/implement_mtf_alignment_and_btc_market_f*`, `backend/tests/market_intelligence/*`.

**Avhengigheter:** BH-06-01.

### BH-06-07 — Implement Spot Futures confirmation evidence
**Forslag eier:** agent_a · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** OI/funding only where available, spot-futures disagreement.

**Negativt akseptansekriterium:** Never impute missing derivatives fields.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/market_intelligence/implement_spot_futures_confirmation_evid*`, `backend/tests/market_intelligence/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-06-08 — Phase 06 indicator golden-test acceptance
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Cross-implement reference on synthetic and real sample windows.

**Negativt akseptansekriterium:** Critical branches and confidence outputs PASS.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/market_intelligence/phase_06_indicator_golden_test_acceptanc*`, `backend/tests/market_intelligence/*`.

**Avhengigheter:** BH-06-01, BH-06-02, BH-06-03, BH-06-04, BH-06-05, BH-06-06, BH-06-07.

## Exit Gate
- Alle tasks PASS på eksakt merge commit.
- Statement og branch coverage kontrollert separat.
- Kritiske negative scenariotester, security scan og evt Windows mål-PC tester PASS.
- Release/testevidence og dokumentasjon oppdatert.
- Bruker GO før neste fase.
