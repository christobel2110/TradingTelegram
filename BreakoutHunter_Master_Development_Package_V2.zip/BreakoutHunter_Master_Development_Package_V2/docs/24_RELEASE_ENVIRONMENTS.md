# To maskiner og portable releases — eksakt ansvar

## Build-PC vs target-PC
- **Build-PC**: superbyggeagentens to kodeagenter utvikler, tester, bygger signerte immutable pakker. Kilder/CI/signing secrets holdes utenfor target-PC.
- **Target-PC**: Windows, oppgitt 16 GB RAM, 8 GB RTX VRAM; vanlig bruker-PC, dedikert disk. Kjør kun pakket program/binærfiler og godkjente modeller, ikke Codex/VS Code/Git/Python globalt.
- Normale driftsdata/modeller/config/logg/Parquet legges på separat disk med relative baner. Windows service registration, GPU-driver og Windows sikkerhetsdatabaser ligger fortsatt på OS-disken.
- Prosessidentitet og ACL gir applikasjonsherding, ikke VM-ekvivalent isolasjon. Bekreft faktisk Windows edition og driver før valg av OS-policy.

## Installer preflight og gate
1. Signatur + hash på release og modellmanifest.
2. CPU, Windows edition, tilgjengelig disk, RTX GPU, driver, VRAM, ledig RAM.
3. Disk ACL og dedikert ikke-admin bruker/tjenestekonto.
4. Endepunkter kun eksplisitt allowlist; GPT Gateway ikke tilgjengelig offentlig før GO.
5. Fersk installasjon uten trading credentials; private BingX API keys forbudt.
6. DB initialisering/migrering idempotent, rollback og atskilt brukerdata.
7. Hver rutine: negative scenario (manglende driver, offline, disk full, ugyldig signatur), forventet return code, recovery logg.

## Installasjon er planlagt, ikke utført
Ingen mål-PC-benchmark, produksjonssandbox eller sikkerhetspolicy kan merkes verifisert uten en faktisk test og signerbare logs. Det samme gjelder gjenoppretting fra separat fysisk medium.
