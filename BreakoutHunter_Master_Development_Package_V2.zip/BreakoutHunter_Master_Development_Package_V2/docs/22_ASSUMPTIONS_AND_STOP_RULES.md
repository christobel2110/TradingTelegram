# Implementation defaults, åpne spørsmål og klare STOP-regler

## Agentene skal ikke spørre om rutinevalg
For teknisk valg uten sikkerhets-/grensesnittpåvirkning: velg enkleste testbare løsning fra `docs/15_IMPLEMENTATION_DEFAULTS.md`. Skriv kort beslutning i ADR bare ved vesentlig endring. Ikke gjenåpne alle 91 steg.

## STOPP og be om eksplisitt brukerbeslutning
1. Private handelsnøkler eller forslag om ekte ordreutførelse (v1 forbudt).
2. Sikkerhetseksponering av GPT Gateway/offentlig domene og autentisering er ikke autorisert.
3. Destruktiv databasemigrering, gjenoppretting eller sletting som ikke er eksplisitt godkjent.
4. Endring av godkjent risikopolicy, ekte kapitalgrenser eller produksjonsstrategi.
5. Kreves en rettighet til Windows/eksterne tjenester som ikke er gitt.
6. Fase 01+ uten `y`, eller motstridende krav med fare for datatap.

## Sikker default ved manglende eksterne data
- Ikke anta aktiv OpenAI API-konto, API-pris, modell-ID, GPT Actions-egenskaper, BingX endepunkter/rate-limits eller Windows-brannmurtilgang.
- Bygg kontrakt og offline fixtures først; mål/test mot faktisk miljø i riktig fase.
- Scanner kan kjøre rule-based hvis Qwen/OpenAI/GPT Gateway er utilgjengelig, men signaler med ugyldige nødvendige datakilder skal være `BLOCK`/stale.
- Installasjonssteg 91 er uavklart: lag read-only driftsspesifikasjon og installasjonsforberedelse, men ikke anta godkjent privilegert automatisk installasjon.

## Når tester feiler
Reproduser nøyaktig én gang, diagnostiser før endring. Ved andre identiske feil: registrer symptom, kontekst, hypoteser og ny plan; ingen tredje blindt identisk kjøring. Om feilen blokkerer kritisk sikkerhet, marker `BLOCKED`.
