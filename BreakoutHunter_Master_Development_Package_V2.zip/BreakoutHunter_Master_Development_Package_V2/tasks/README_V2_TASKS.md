# How to use machine-readable backlog

**Authoritative:** `TASK_BACKLOG_V2.json` + individual `cards/BH-XX-YY.md`. V1 `TASK_BACKLOG.json` is retained only for historical comparison and must not be dispatched.

Choose task READY iff (a) phase approved by user, (b) every `depends_on` has integrated PASS with exact merge commit, (c) `write_set` does not intersect an active lease, (d) required inputs, mocks, contracts and negative tests are available. `owner_hint` is only a suggestion; do not implement orchestration inside BreakoutHunter.

Cards are generated from V2 backlog, not separately hand-maintained. To update, change machine-readable source and regenerate cards with identical requirements and smoke-validate. Never treat string-based test oracles as substitute for executable fixtures.
