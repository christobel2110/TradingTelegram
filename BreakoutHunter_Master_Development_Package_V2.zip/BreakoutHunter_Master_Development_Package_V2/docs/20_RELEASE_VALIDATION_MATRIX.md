# Release Validation Matrix — evidence tied to exact build

| Gate | Phase first needed | Required evidence | Fail closed |
|---|---|---|---|
| Requirements / DAG | 00 | validator output 91 source steps, 141 valid tasks, no cycles, 91 proposal locked | yes |
| Locked dependencies | 00 | lock hash, tool versions, SBOM/scan, signature of third-party binaries | yes on high-severity unreviewed |
| 100% statements and branches | 00 → every phase | separate coverage counts on critical own-code + exclusions reviewed | yes |
| CI cannot bypass | 00 + GitHub admin | protected main/ruleset, PR + merge_group checks, no bypass, known CI actor | yes before declaring protected |
| Windows ACL/firewall service | 02 & final | tests on target Windows edition/user, denied outside write/net paths | yes |
| Event journal transaction | 03 | forced kill between commit/send; exactly one state transition after replay | yes |
| Public BingX market adapters | 04 | official current endpoint/version evidence + golden raw fixtures + live read-only smoke | yes if unverified |
| Historical archive | 05 | row/time/hash equality, interrupted atomic file publication | yes |
| SMC/no lookahead | 06 | last-right-pivot pending, historical replay equals causal streaming | yes |
| Breakout gate | 07 | closed-candle, invalid feed, fail/expiry states | yes |
| Risk gates | 08 | boundary/Decimal tick/slippage/margin/property cases | yes |
| Paper/shadow | 09 | same event replay yield identical ledger, no live order route | yes |
| Model runtime | 10 | actual target memory/quality/driver measurements | disabled until pass |
| API and GPT read-only | 11 | auth, rate-limit, blocked POST/admin, verified HTTPS+domain | disabled until pass |
| Research science | 12–14 | OOS, purging, multiple testing, cost realism, shadow status | shadow only until pass |
| Dashboard | 15 | auth/MFA/RBAC, CSRF/CORS, E2E mobile read-only | no admin until pass |
| Backup/update | 16 | external restore rehearsal + signer verification + rollback | no production-ready until pass |
| Clean installation | 17 | signed release, no global Python, separate disk, no order traffic, soak test | yes |

## What MUST remain unverified in docs
Exact production performance, Windows security isolation, reliability under power loss, model quality, Cloudflare/GPT Actions connectivity, available OpenAI model IDs and BingX quotas are untested until work is performed. Written specifications cannot earn PASS.
