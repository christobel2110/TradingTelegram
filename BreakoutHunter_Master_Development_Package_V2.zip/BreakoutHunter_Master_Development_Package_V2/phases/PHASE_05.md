# PHASE 05: Tiered Market Data & Fast Processing

**Mål:** Efficient hot/warm/cold and incremental computation.

**Inngang:** Fase 04 godkjent med faktisk CI-evidence og GO.

**Relevant kildesteg:** BH-REQ-054, BH-REQ-055, BH-REQ-056

## Ferdigdefinerte kodeoppgaver (kan fordeles mellom 2 agenter)

### BH-05-01 — Design Parquet partitions and manifests
**Forslag eier:** agent_a · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** ZSTD partitions with version/hash/time metadata.

**Negativt akseptansekriterium:** Restore detects missing/corrupt archived partition.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/data_platform/design_parquet_partitions_and_manifests*`, `backend/tests/data_platform/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-05-02 — Implement atomic HOT-to-COLD archival
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Write temp, verify, publish, retain hot until safe.

**Negativt akseptansekriterium:** Crash during publish cannot lose verified rows.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/data_platform/implement_atomic_hot_to_cold_archival*`, `backend/tests/data_platform/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-05-03 — Implement unified Data Access Layer
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Market/Research SQL and Parquet query facade.

**Negativt akseptansekriterium:** Consumers read same timestamp semantics.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/data_platform/implement_unified_data_access_layer*`, `backend/tests/data_platform/*`.

**Avhengigheter:** BH-05-01.

### BH-05-04 — Implement bounded columnar batch reads
**Forslag eier:** agent_b · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** PyArrow/Polars lazy scans and limited columns/windows.

**Negativt akseptansekriterium:** Research RAM respects configured cap.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/data_platform/implement_bounded_columnar_batch_reads*`, `backend/tests/data_platform/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-05-05 — Implement versioned Shared Feature Cache
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** LRU key includes parameters/code/data/timeframe/closed.

**Negativt akseptansekriterium:** Changed data hash invalidates feature.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/data_platform/implement_versioned_shared_feature_cache*`, `backend/tests/data_platform/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-05-06 — Implement incremental indicator API primitive
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Per symbol/TF updates with deterministic reference result.

**Negativt akseptansekriterium:** Incremental equals full recomputation within tolerance.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/data_platform/implement_incremental_indicator_api_prim*`, `backend/tests/data_platform/*`.

**Avhengigheter:** BH-05-01.

### BH-05-07 — Phase 05 storage and performance acceptance
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** 100-symbol target benchmark + crashes/retention check.

**Negativt akseptansekriterium:** No uncontrolled memory growth or hidden data gaps.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/data_platform/phase_05_storage_and_performance_accepta*`, `backend/tests/data_platform/*`.

**Avhengigheter:** BH-05-01, BH-05-02, BH-05-03, BH-05-04, BH-05-05, BH-05-06.

## Exit Gate
- Alle tasks PASS på eksakt merge commit.
- Statement og branch coverage kontrollert separat.
- Kritiske negative scenariotester, security scan og evt Windows mål-PC tester PASS.
- Release/testevidence og dokumentasjon oppdatert.
- Bruker GO før neste fase.
