# Machine-Enforced Quality Gates — binding mellom commit og bevis

## Definition of Done per task
- Scope og relevante krav-ID-er bevart; ingen kritisk sikkerhetsregel utelatt; codeowner og file ownership OK.
- Unit + contract + integration (og e2e/fault/security/perf når berørt) testkjørt i låst, reproduserbart miljø.
- Statement coverage 100 % **separat fra** branch coverage 100 % av egen kritisk Python-kode. Total-prosent fra pytest alene er IKKE nok. For annen egen kode samme kvalitetsmål, med eksplisitt risikogodkjent exclusion-registrering.
- Lint/format (Ruff), typer (Pyright/Mypy), Dependency/SAST/secret scan, invariants, no-order policy.
- Logger/testbevis har git HEAD SHA, avhengighetslock hash, testkommando, verktøyversjoner, Python/OS, tidspunkt, exit status og filhash; reviews peker til samme commit.
- Ingen skipped/xfail for kritiske tester; skip av plattformspesifikk test krever sporet aksept og annen faktisk mål-PC kjøring før release.
- Oppdatert dokumentasjon/progress, changelog, regressions.

## Eksempel på separat coverage-gate
`pytest -q --cov=breakouthunter --cov-branch --cov-report=json:coverage.json --cov-report=term-missing`

`coverage.json` har `totals.num_statements`, `totals.covered_lines`, `totals.num_branches`, `totals.covered_branches`. Assert **covered_lines == num_statements** OG **covered_branches == num_branches**. Code-defined exclusions dokumenteres og kontrolleres; ingen glob som skjuler kritiske filer.

## Verifikasjon/commit-ID
- Installer/test pipeline kjører fra immutable PR head SHA eller merge queue SHA.
- Evidence-path `reports/evidence/<task>/<sha>/` (CI artifact, ikke direkte i repo). Manifest inneholder SHA til testloggene og workflow run ID.
- Merge gate sjekker at PASS knyttes til akkurat oppdatert commit (ingen `push` etter review uten nye tester).
- GitHub required status checks, branch ruleset/review/no self approval/no bypass for relevante roller må konfigureres i GitHub UI/admin; yaml alene håndhever ikke beskyttelse.

## Kritiske scenario-tester (ikke bare linjedekning)
Feed gap/out-of-order, WebSocket reconnect, stale data, crash between journal+outbox, power failure restore, partial fills, gap slippage, cross-market cross-strategy, float/decimal rounding, look-ahead purge, model invalid JSON, GPT API budget exhaustion, filesystem access denial, secrets redaction, malicious release, 2 concurrent agent worktrees, Windows target user permissions.

## QA-gater etter fase
1. per-task targeted tests
2. pre-merge full Python+frontend+security+contract check
3. post-merge integration at tested SHA
4. phase acceptance demo and benchmarks with versioned fixtures
5. user approval before next phase.

## Uavhengig review policy
HIGH: risk engine, account/gateway auth, event journal, updater, migration, recovery, installer, model supply chain, safe egress. Reviewer separat agent eller autorisert reviewer, ingen self-approval. MEDIUM: focused diff + impacted code. LOW: deterministic QA. For sikkerhetskritisk kode kan testutfall IKKE overstyres av skjønn.

## Source-of-truth for test evidence
`templates/EVIDENCE_MANIFEST.example.json` angir schema. `scripts/check_coverage.py` er bare dokumentstøtteverktøy; byggeagenten skal integrere dette i ekte CI og bevise at gate ikke kan omgås.
