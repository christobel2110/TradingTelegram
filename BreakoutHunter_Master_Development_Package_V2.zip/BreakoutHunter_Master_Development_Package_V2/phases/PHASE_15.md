# PHASE 15: Command Center & Mobile

**Mål:** Operator visibility and safe phone access.

**Inngang:** Fase 14 godkjent med faktisk CI-evidence og GO.

**Relevant kildesteg:** BH-REQ-021

## Ferdigdefinerte kodeoppgaver (kan fordeles mellom 2 agenter)

### BH-15-01 — Implement FastAPI read dashboard facade
**Forslag eier:** agent_a · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** Localhost auth scoped signal/research/system models.

**Negativt akseptansekriterium:** Cannot starve scanner queries.

**Skriveområde (foreslått lease):** `frontend/src/implement_fastapi_read_dashboard_facade*`, `frontend/tests/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-15-02 — Implement React radar and charts
**Forslag eier:** agent_b · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** Spot/futures candidate states, timestamps and entry overlays.

**Negativt akseptansekriterium:** All demo values flagged or actual verified.

**Skriveområde (foreslått lease):** `frontend/src/implement_react_radar_and_charts*`, `frontend/tests/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-15-03 — Implement Research Inbox and governance UI
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Approval view with hash/policy and reauth.

**Negativt akseptansekriterium:** Read-only GPT never serves approval link alone.

**Skriveområde (foreslått lease):** `frontend/src/implement_research_inbox_and_governance_*`, `frontend/tests/*`.

**Avhengigheter:** BH-15-01.

### BH-15-04 — Implement app login MFA and RBAC
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Roles read/operator/admin + CSRF protection.

**Negativt akseptansekriterium:** Read user denied admin action.

**Skriveområde (foreslått lease):** `frontend/src/implement_app_login_mfa_and_rbac*`, `frontend/tests/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-15-05 — Implement VPN-based mobile access
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Tailscale serve/private VPN only, no open dashboard public.

**Negativt akseptansekriterium:** Phone auth+offline stale indicators.

**Skriveområde (foreslått lease):** `frontend/src/implement_vpn_based_mobile_access*`, `frontend/tests/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-15-06 — Implement resource, alerts, audit dashboards
**Forslag eier:** agent_b · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** RAM/VRAM/CPU, queues, costs and data staleness.

**Negativt akseptansekriterium:** Unknown metric shown unknown not healthy.

**Skriveområde (foreslått lease):** `frontend/src/implement_resource_alerts_audit_dashboar*`, `frontend/tests/*`.

**Avhengigheter:** BH-15-01.

### BH-15-07 — Phase 15 frontend security and accessibility QA
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D3_Critical

**Leveranse:** E2E auth/accessibility/UI state tests.

**Negativt akseptansekriterium:** No destructive actions via mobile read role.

**Skriveområde (foreslått lease):** `frontend/src/phase_15_frontend_security_and_accessibi*`, `frontend/tests/*`.

**Avhengigheter:** BH-15-01, BH-15-02, BH-15-03, BH-15-04, BH-15-05, BH-15-06.

## Exit Gate
- Alle tasks PASS på eksakt merge commit.
- Statement og branch coverage kontrollert separat.
- Kritiske negative scenariotester, security scan og evt Windows mål-PC tester PASS.
- Release/testevidence og dokumentasjon oppdatert.
- Bruker GO før neste fase.
