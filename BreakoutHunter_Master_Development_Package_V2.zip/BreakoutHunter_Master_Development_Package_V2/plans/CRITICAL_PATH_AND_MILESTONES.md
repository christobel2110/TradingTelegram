# Implementasjonsrekkefølge og leveranse-gates

## Lovede milepæler (verifiser ved QA, ikke kalenderdato)
| Gate | Faser | Minimal etterprøvbar leveranse |
|---|---|---|
| M0 | 00–01 | QA på eksakt SHA, versjonerte JSON-datakontrakter, negative fixtures, beskyttet main-plan |
| M1 | 02–04 | herdet Windows preflight+runtime, holdbar Market DB/outbox, BingX dataadapter på offline fixtures og read-only smoke |
| M2 | 05–07 | verifisert Parquet pipeline, causal SMC/Fib/indikatorer, WATCH/ARMED/CONFIRMED og Telegram mock-outbox |
| M3 | 08–09 | hard risk gate, paper/shadow ledger, real-execution forbidden egress-test |
| M4 | 10–11 | ressursstyrt Qwen + OpenAI budget, secure read-only GPT Gateway (disabled until GO) |
| M5 | 12–14 | vitenskapelig Research, walk-forward, evidence gates, drift/memory på rene datasets |
| M6 | 15–17 | Command Center, sikker backup/update, mål-PC preflight, ende-til-ende installasjonsbevis |

## Ikke blokker parallelt arbeid uten grunn
Innen **godkjent fase**, fordel kontraktkompatible, forskjellige `write_set` til to eksterne kodeagenter. `depends_on` er harde porter. Agent B kan lage offline adapter/tests i parallell med Agent A på koden som senere skal implementere kontrakten. Ikke parallellskriv samme fil. Integrer i én kø; full fasepass ved siste acceptance task.

## Kritisk rekkefølge og ressursvern
Sikkerhetsgrenser, datakontrakter og journal/outbox før live scanner og senere AI. Backtests får aldri trenge GPU. GPU inferens må ikke blokkere scanner. Prøv ikke finansielle sannsynlighetsprediksjoner før historiske labels/tidslekkasjekontroller er bestått.
