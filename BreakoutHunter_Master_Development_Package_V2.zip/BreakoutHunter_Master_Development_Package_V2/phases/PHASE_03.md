# PHASE 03: Durable Event & Storage Kernel

**Mål:** Build safe journal and split database base.

**Inngang:** Fase 02 godkjent med faktisk CI-evidence og GO.

**Relevant kildesteg:** tverrfase krav i `requirements_registry.json`

## Ferdigdefinerte kodeoppgaver (kan fordeles mellom 2 agenter)

### BH-03-01 — Initialize Market SQLite and migrations
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D3_Critical

**Leveranse:** WAL, FK, indexed instrument/candle/event/state tables.

**Negativt akseptansekriterium:** Migration interruption preserves known schema.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/data_platform/initialize_market_sqlite_and_migrations*`, `backend/tests/data_platform/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-03-02 — Build append-only event journal and outbox
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Stable IDs, durable transaction, at-least-once sender.

**Negativt akseptansekriterium:** Crash cannot silently drop committed signal.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/data_platform/build_append_only_event_journal_and_outb*`, `backend/tests/data_platform/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-03-03 — Implement single-writer market persistence
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Bounded write queue, transaction lengths and retry policy.

**Negativt akseptansekriterium:** Lock contention fails closed instead of dropping events.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/data_platform/implement_single_writer_market_persisten*`, `backend/tests/data_platform/*`.

**Avhengigheter:** BH-03-01.

### BH-03-04 — Initialize Research SQLite separately
**Forslag eier:** agent_b · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** Experiment/validation metadata with independent writer.

**Negativt akseptansekriterium:** Research DB outage does not stop Market DB.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/data_platform/initialize_research_sqlite_separately*`, `backend/tests/data_platform/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-03-05 — Implement idempotent market-to-research sync
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Watermark, content-hash, dedupe, replay checkpoint.

**Negativt akseptansekriterium:** Replayed batch generates no duplicates.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/data_platform/implement_idempotent_market_to_research_*`, `backend/tests/data_platform/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-03-06 — Implement consistent SQLite snapshot adapter
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Online Backup API and restore integrity check.

**Negativt akseptansekriterium:** Snapshot consistent with active WAL.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/data_platform/implement_consistent_sqlite_snapshot_ada*`, `backend/tests/data_platform/*`.

**Avhengigheter:** BH-03-01.

### BH-03-07 — Phase 03 fault injection
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Kill between write/outbox/checkpoint, restart reconciliation.

**Negativt akseptansekriterium:** No duplicate logical events after replay.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/data_platform/phase_03_fault_injection*`, `backend/tests/data_platform/*`.

**Avhengigheter:** BH-03-01, BH-03-02, BH-03-03, BH-03-04, BH-03-05, BH-03-06.

## Exit Gate
- Alle tasks PASS på eksakt merge commit.
- Statement og branch coverage kontrollert separat.
- Kritiske negative scenariotester, security scan og evt Windows mål-PC tester PASS.
- Release/testevidence og dokumentasjon oppdatert.
- Bruker GO før neste fase.
