#!/usr/bin/env python3
"""Validate wire DTO positive and negative cases (requires jsonschema>=4)."""
import json
from pathlib import Path
try:
    from jsonschema import Draft202012Validator, FormatChecker
except ImportError as exc:
    raise SystemExit('BLOCKED: install jsonschema in isolated docs QA environment') from exc
ROOT=Path(__file__).resolve().parents[1]
S=ROOT/'contracts/jsonschema'; V=ROOT/'contracts/fixtures/valid'; N=ROOT/'contracts/fixtures/invalid'

def run():
    cases=json.loads((ROOT/'contracts/fixtures/INVALID_CASES.json').read_text())
    valid_count=0
    for file in V.glob('*.json'):
        model=file.stem; schema=json.loads((S/(model+'.schema.json')).read_text())
        Draft202012Validator.check_schema(schema)
        Draft202012Validator(schema,format_checker=FormatChecker()).validate(json.loads(file.read_text()))
        valid_count+=1
    assert valid_count>=8, 'Too few positive schemas tested'
    for c in cases:
        schema=json.loads((S/(c['model']+'.schema.json')).read_text())
        data=json.loads((ROOT/c['file']).read_text())
        issues=list(Draft202012Validator(schema,format_checker=FormatChecker()).iter_errors(data))
        assert issues, f"INVALID fixture accepted: {c['file']}"
    assert len(cases)>=15
    print(f'PASS: {valid_count} positive + {len(cases)} intentionally rejected fixture cases')
if __name__=='__main__':run()
