# AGENTS.md — kontrakt for Superbyggeagentens to kodeagenter

**V2-first:** `tasks/TASK_BACKLOG_V2.json` og `tasks/cards/` er autoritative taskspesifikasjoner. `tasks/TASK_BACKLOG.json` er V1-arkiv og SKAL IKKE dispatches. Se `README_START_HER.md`, `docs/15_IMPLEMENTATION_DEFAULTS.md`, `docs/23_CONTRACT_SEMANTICS.md` og `prompts/START_SUPERBYGGEAGENT_V2.md`.


## Prioritert oppdrag
Bygg **BreakoutHunter**, ikke et ekstra Superbyggeagent-system. Dokumentpakken er autoritativ for produktkrav. Ved konflikt: ufravikelig sikkerhet > datakontrakter > godkjent beslutningsregister > faseoppgaver > eksempler. Rapporter konflikt; gjett aldri private nøkler, finansielle fakta eller godkjenning.

## Worktree/rollegrense
- To **eksterne** kodeagenter kan bruke separate worktrees/branches. Orkestreringen eies av brukerens Superbyggeagent.
- Maks én ansvarlig skribent per fil ved samme tidspunkt. Delte kontrakter skal godkjennes/integreres før videre parallellitet.
- Agent A/B får en konkret TASK_ID, skrive-allowlist og minimal kontekstpakke. Ikke les hele repo ukritisk.
- Main er beskyttet: ingen direkte push; uavhengig review av HIGH-risiko; merged HEAD skal være nøyaktig den testede commit.
- Eksterne builder-agenter skal ikke få produksjonshemmeligheter, tradingkonti eller ubegrenset internett/filsystem.

## Arbeidsflyt for hver oppgave
1. Les aktuell oppgavespesifikasjon og kontrakter; verifiser forutsetninger og git-status.
2. Implementer minste sammenhengende endring; skriv tester for normal, kant, negativ og fault-path.
3. Kjør målrettede tester og lint mens du utvikler. Gjenta ikke identisk mislykket reparasjon: etter andre identiske feil, stopp og revider rotårsaksdiagnose.
4. Før commit/merge: full kvalitetsgate for endret scope + integrasjon på mergebasen; isoler feilårsaker.
5. Produser `reports/evidence/<task_id>/<commit_sha>/...` med testkommando, miljø, tidsstempel, exit-koder, coverage og hash på logger.
6. Etter QA leverer agenten endrings-/testbevis. **Superbyggeagentens integrasjonsansvarlige** oppdaterer `PROJECT_STATE.md`, faseplaner og `CHANGELOG.md` etter godkjent merge, fordi de globale filene ikke inngår i utvikleroppgavens `write_set`. Ingen fiktive PASS.
7. Stopp ved fasegrensen. Be brukeren om `y` før neste fase, ikke nødvendigvis før hver deloppgave.

## Ikke-forhandlingsbare krav
- **No live trading**: ingen produksjonskode som skriver ordre på BingX i v1; test med forbudt-destinasjon/rettigheter.
- ChatGPT Gateway: kun autentiserte read-only GET endepunkter, uten API-nøkler, prosesskontroll eller godkjenning.
- Kritiske beslutninger regnes deterministisk i Python, ikke av LLM. Manglende eller stale data => feil/status, ikke gjetning.
- 100 % statements og **100 % branches** separat for egen kritisk Python-kode. Frontend tilsvarende for kritiske kontroller. Coverage kan ikke erstatte integrasjons- og feilinjeksjonstesting.
- CI må dokumentere sikkerhetsgater; ekstern GitHub branch protection/rulesets må også konfigureres av autorisert bruker.
- Tjenester uten nødvendig nett/disk/hemmelighet kan aldri «fikse» manglende tillatelse selv.
- Bruk stabile ID-er, decimal-strenger til pris/risiko, ISO 8601 UTC, as-of datatidsstempler, proveniens og immutable strategi/release-versjoner.

## Usage policy
- Bruk **laveste dokumentert tilstrekkelige modellnivå**. Ikke anta modell- eller programmatisk byttetilgang. Se `docs/06_MODEL_USAGE_POLICY.md`.
- Generer context pack for oppgaven: kontrakter, endret kode, relevante tester, tidligere blokkeringer. Hold godkjent sikkerhetsinstruks uendret.
- Lokale pytest/ruff/pyright/coverage-kjøringer utføres uten AI-genererte forklaringer for hvert grønt resultat.
- Hent kun relevante diff/hendelsesbevis til review; krev ekstra kontekst ved kritisk risiko.
- Agentene skal ikke doble backtesting/GPT-analyse som allerede er verifisert på identiske data og konfigurasjon.

## Sluttformat per oppgave
`TASK_ID | commit SHA | files changed | tests + coverage statements/branches | security result | performance result | source evidence | PASS/BLOCKED | next dependents`

## V2-preferanse ved uklarhet
De individuelle `tasks/cards/BH-XX-YY.md` sine eksakte `write_set` og orakler overstyrer brede fasebeskrivelser fra V1. Ved behov for flere filer: lag ny koordinert oppgave, ikke omgå grensen.
