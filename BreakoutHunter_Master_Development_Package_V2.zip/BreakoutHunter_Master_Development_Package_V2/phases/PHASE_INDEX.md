# Utviklingsfaser (sortert etter tekniske avhengigheter)

| Fase | Navn | Oppgaver | Formål |
|---|---|---:|---|
| 00 | Governance & Quality Foundation | 7 | Lock scope, rules and CI before writing trading code |
| 01 | Canonical Contracts | 8 | Version all shared interfaces before parallel code |
| 02 | Portable Sandbox & Runtime Foundation | 8 | Protect target PC and isolate critical scanner |
| 03 | Durable Event & Storage Kernel | 7 | Build safe journal and split database base |
| 04 | BingX Public Feeds & Discovery | 8 | Real market data without trading credentials |
| 05 | Tiered Market Data & Fast Processing | 7 | Efficient hot/warm/cold and incremental computation |
| 06 | Indicators, SMC & Regime | 8 | Deterministic multi-timeframe market intelligence |
| 07 | Breakout Opportunity Engine | 8 | Early and confirmed opportunities with deterministic ranking |
| 08 | Risk & Entry Policy | 8 | Fail-closed risk engine, no live orders |
| 09 | Paper, Shadow & Telegram MVP | 8 | Traceable trade simulation and safe alerts |
| 10 | Portable Hybrid AI & Usage | 9 | Local llama.cpp, cloud fallback and context optimization |
| 11 | Read-only GPT Gateway & Research Inbox | 7 | Custom GPT analysis without privileged control |
| 12 | Research Kernel & Backtesting | 8 | Autonomous bounded research within approved scope |
| 13 | Scientific Validation & Strategy Governance | 8 | Evidence gate and human-controlled strategy change |
| 14 | Advanced Learning, Drift & Probability (shadow) | 9 | Research-only advanced ranking and validated memory |
| 15 | Command Center & Mobile | 7 | Operator visibility and safe phone access |
| 16 | Controlled Updates, Backup & Disaster Recovery | 9 | Safe offsite recovery and signed updates |
| 17 | Physical Target-PC Installation & Final Release | 7 | Verify portable, protected, usable v1 end to end |

**Faseregler:** Oppgaver inne i én godkjent fase kan jobbes parallelt i eksisterende Superbyggeagent; selve faseovergangen krever dokumentert PASS og bruker-GO. P0-risiko implementeres ikke bevisst sent bare fordi den blir nevnt i en senere fase.
