# Research & Scientific Validation Plan

## Testbar hypotese og tidsintegritet
Forskningshypotese, feature list, label, tidsperiode, primary endpoint, param search limits, seed, kostnadsmodell og stop-kriterier skal forhåndsregistreres. Candles, regime, Fib pivoter og FVG definert med *available-as-of* og no-lookahead. Data splitting med chronological train/validation/OOS, purging + embargo for overlapping labels. Ikke bruk OOS gjentatte ganger som utviklingssett; søkeforsøk/tapere registreres.

## Baseline før modell
Simple breakout-only, breakout+volume, regime filter, Qwen assisted, GPT assisted, memory/probability features. Stratifiser etter Spot/Futures, LONG/SHORT, regime og liquidity. Separate occurrence probability from trade outcome probability; p(breakout) er ikke p(win). Score på 88/100 er ikke 88%.

## Sannsynlighetsmodell
Definer tidsfrister og hendelser: trigger price, close-time confirmation, buffer, horizon, competing failed/expired, censored outcomes ved avbrutt observasjon. Calibrated probability med Brier/log loss/reliability curve/CI og drift monitoring. Start med empirisk frekvens og logistisk regresjon; trebasert modell kun om validert uplift. Probability og evidence-calibrated ranking forblir SHADOW inntil Shadow Arena + menneskelig GO.

## Robusthet og trading reality
Simulator på candle-data må merke upresist fill; ikke late som best-price fills garantert. Fees maker/taker, spread, slippage, funding, latency, queue/partial fills, isolated leverage, liquidation, mark/last triggers; stresstest gaps. Mål expectancy i R, PF med uncertainty, OOS drawdown, max stress loss, regime stability, sample effective size, turnover, time-to-breakout, cancellation/false alerts.

## Champion–Challenger
Baseline fryses. Pareto: return/risk/robustness/execution/evidence, max 3 diverse challengers, separate shadow ledgers; research kan foreslå, ikke promotere. Evidence Gate PASS/WAIT/FAIL etter forhåndsdefinerte statistiske + safety krav. Human GPT evidence-first: råtall før Research Labs anbefaling; ChatGPT-GPT kan ikke approve via read-only gateway.

## Drift og læring
PSI/JS/KS/Page-Hinkley der validert, ikke p-verdier alene. Drift = årsakshypotese, ikke konklusjon. `UNKNOWN` stans relevante adaptive features. Disagreement memory: kun validerte dokumenterte feil, ikke konsensus som fasit. Memory-based scorejustering først SHADOW, deretter positiv OOS-evidens og GO. Grenser initielt ±5 points kun forskningshypotese.

## Resource Priority
Maks én tung job, bounded search, dedup fingerprint strategy code/data/cost/params/seed, low priority, checkpoint, abort under minnepress; ingen autonome endringer av vitenskapelige minimumskrav. AI-assistert hypoteseforming kun etter ressurser, GPT research reviews primært via brukerens Custom GPT for non-timecritical.

## Kritiske QA-evals
Falsk look-ahead i bevispakker, censored vs false, mislabeled horizon, class imbalance, stationarity shift, repeated OOS peek, strategy variant explosion, correlation/cluster dependence, overconfidence, alternative fills, negative result logging, sample scarcity. Refuserer model promotion ved manglende dokumentasjon.
