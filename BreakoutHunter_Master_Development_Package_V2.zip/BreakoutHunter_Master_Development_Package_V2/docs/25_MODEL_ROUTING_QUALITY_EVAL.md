# Usage-optimert modellruting for Superbyggeagentens to kodeagenter

**Mål:** minimere samlet usage **per godkjent oppgave** uten at risikogrensene svekkes. Superbyggeagenten styrer modelldispatch; BreakoutHunter skal ikke kode sin egen Codex-orchestrator.

## Policy
1. **No-AI** først: formattering, testkjøringer, coverage, skjema- og DAG-validering, filhash, generering av task cards. Ingen modellkall når deterministisk verktøy kan gjøre samme jobb.
2. `D1_Standard`: presise småendringer med låst kontrakt, testfixture og begrenset filomfang. Start med billigste **tilgjengelige og eval-testede** modell som består kvalitetsmål.
3. `D2_Complex`: for API-samtidighet, statemaskiner, integrasjon og filsystem; *anbefalt kapasitetstak*, ikke automatisk krav om dyreste modell hver gang. Enkel dokumentasjon under et D2-task kan utføres deterministisk/D1; krev full D2-review dersom grensesnitt eller sikkerhet endres.
4. `D3_Critical`: risiko, økonomiske beregninger, signaturer, ordregrenser, autentisering og kritisk recovery. Bruk sterkeste **tilgjengelige og kvalifiserte** modell og obligatorisk uavhengig review. Billigere modell kan bare godkjennes etter konkret eval mot likt testsett, ikke basert på ønsket besparelse.
5. Modell-ID, effort og tilgang er **ikke antatt**. Gjennomfør capability-preflight på faktisk Codex-klient og registrer gyldig mapping. En egendefinert GPT i ChatGPT er ikke en automatisk erstatning for OpenAI API eller Codex.

## Styring av kontekst
For hver oppgave: kort task card + oppdaterte kontrakter + berørte filer + negative tests + eventuelle tidligere blockers. Aldri send hele 91-stegs historikken. Bruk `git diff --stat` og nøkkeleksempler i review; les mer bare ved vesentlig behov. For kritiske saker går sikkerhet foran tokenmål. Mellomfasene har en liten `PROJECT_STATE.md` som inkluderer siste godkjente SHA.

## Modellbenchmark må inneholde
Korrekthet på samme skjulte testoppgaver, antall regresjoner, review-funn, fullføringstid, tokens hvis observert, samlet usage, redigert kildekode, og andel blokkerte HIGH-problemer. Test både valgte modellnivåer med identisk kontekstpakke og samme QA-gates. Ingen kvalitetspåstander bare fordi en modell er dyrere.

## Forsøk og eskalering
Én presis reparasjon etter rotårsaksanalyse. Samme feil andre gang → stopp, hent nye observasjoner, revider plan/modellnivå eller meld blokkering. Ikke bruk tre high-reasoning modeller på samme feil uten ny informasjon. Modellbytte er kun en anbefaling dersom brukerens klient ikke kan bytte automatisk.

## Faktiske rapporteringsfelter
`task_id`, SHA, `model_id` hvis kjent, `reasoning_effort` hvis tilgjengelig, `reported_usage` eller NULL, P50/P95 testlatency hvis tilgjengelig, QA status, review defects, rework count. Ikke estimer abonnementstokens fra antall filer.
