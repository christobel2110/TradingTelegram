# Modulspesifikasjoner (konsolidert fra kildesteg 01–91)

## M1 Foundation
Python backend package + React/Vite kun i dashboard. Type-checked schema, klokke, logger, config, interne eventtyper, feature flags og sikker default. 100% separat coverage på kritisk kode. Ingen runtime avhengighet til dev/builders.

## M2 Data Platform
BingX Spot/Swap public channels via versjonerte adaptere, public REST bootstrap/backfill, gzip + ping/pong der offisiell dokumentasjon tilsier; instrument discovery, ordrebok/trade sampling under rate limits. Watermarks gap checks. Critical writer Market SQLite; Research SQLite idempotent import; Parquet/ZSTD. Ferskhet/kompletthet må beregnes før signal.

## M3 Indicators & SMC
RSI, MACD, ATR, RVOL, Bollinger/volatility squeeze, trend/MTF, pivoter med confirm-right-bars, BOS/CHoCH, FVG, OB, liquidity sweeps og Fibonacci retracement/extensions. Inkrementell beregning vs batch referanse, eksplisitte parametere og warmup. Ingen repaint/look-ahead.

## M4 Opportunity
Early WATCH/ARMED + CONFIRMED/RETEST/FAILED/EXPIRED; readiness (ATR-distance), breakout quality, likelihood shadow, opportunity ranking og hard eligibility gates. Spot LONG, futures LONG/SHORT separate scorer. Skiller «score» fra sannsynlighet og simulerer ingen fill i detection.

## M5 Risk & Paper
Strukturell invalidation, ATR-buffer, TP liquidity/extensions, net R:R etter costs, conservative slippage. Fail-closed ALLOW/REDUCE/BLOCK/HALT; planned risk og stress loss/cluster risk skilt. Paper simulator med plausibel order queue/partial fill/fees/funding/margin; Shadow strategier isolerte.

## M6 Hybrid AI
Local portable llama.cpp Qwen GGUF kandidat; hardware benchmark/lifecycle. API client med faktiske godkjente model IDs, budget reservation + reconciliation, max calls, fallback. Context levels L1/L2/L3 + validated compression/provenance, negative caching TTL. LLM output aldri til orders/gates.

## M7 GPT & UI
Read-only secure GPT Gateway med smal OpenAPI, GET-auth/limits/read-model; ChatGPT Custom GPT som evidence-first kritisk strategirevisor. Telegram varsler og research inbox. Local dashboard og privat mobil VPN. Ingen GPT-initiated write approval.

## M8 Research
Pre-registrert hypothesis, realistic backtest, out-of-sample, purging/embargo, multiple testing register, param search, reproducibility manifests, Pareto selection, max 3 challenger shadow, probability calibration, regime/drift, ROI. Forskningsjobber pause ved ressursmangel.

## M9 Knowledge & Governance
Validated analogs, disagreement memory, context-checks og evidence refs; baseline/adjustment held separate; risky changes require manual GO tied to immutable commit/strategy/config version. Research may propose only. No automatic trading.

## M10 Operations/Deployment
Hardened Windows service/non-admin account, dedicated disk app/data/models, signed release/model manifest, GPU/CPU fallback, automatic setup after user inputs credentials, environment health. Backup provider local/NAS/cloud, offsite encryption and monthly restore drills, rollback of code distinct from DB rollback.
