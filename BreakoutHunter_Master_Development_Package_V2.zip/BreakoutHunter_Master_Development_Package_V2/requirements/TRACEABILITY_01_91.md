# Sporbarhetsmatrise: kildesteg 01–91

| Kildesteg | Krav-ID | Konsolidert funksjon | Hovedområde | Fase | Prioritet | Status |
|---:|---|---|---|---:|---|---|
| 01 | BH-REQ-001 | Hybrid lokal utvikling / senere VPS | ARCH | 00 | P0 | DOCUMENTED_APPROVED |
| 02 | BH-REQ-002 | Kjernearkitektur Python og GPT roller | ARCH | 00 | P0 | DOCUMENTED_APPROVED |
| 03 | BH-REQ-003 | Ressursstyring for delt PC | OPS | 02 | P0 | DOCUMENTED_APPROVED |
| 04 | BH-REQ-004 | Windows automatisk bakgrunnsstart | DEP | 02 | P0 | DOCUMENTED_APPROVED |
| 05 | BH-REQ-005 | WATCH CONFIRMED RETEST FAILED | OPP | 07 | P1 | DOCUMENTED_APPROVED |
| 06 | BH-REQ-006 | Multi-Strategy SMC/Fib/volum | INTEL | 06 | P1 | DOCUMENTED_APPROVED |
| 07 | BH-REQ-007 | Adaptive scoring per regime | OPP | 07 | P1 | DOCUMENTED_APPROVED |
| 08 | BH-REQ-008 | Autonom Research Lab med godkjenning | RESEARCH | 12 | P2 | DOCUMENTED_APPROVED |
| 09 | BH-REQ-009 | Research Director og minne | RESEARCH | 12 | P2 | DOCUMENTED_APPROVED |
| 10 | BH-REQ-010 | Intelligent Resource Manager og AI Router | AI | 10 | P1 | DOCUMENTED_APPROVED |
| 11 | BH-REQ-011 | Kun lokal drift + coin discovery | DATA | 04 | P1 | DOCUMENTED_APPROVED |
| 12 | BH-REQ-012 | Spot og futures intelligent bekreftelse | INTEL | 06 | P1 | DOCUMENTED_APPROVED |
| 13 | BH-REQ-013 | Advanced Opportunity Ranking | OPP | 07 | P1 | DOCUMENTED_APPROVED |
| 14 | BH-REQ-014 | Adaptive Entry Intelligence | RISK | 08 | P1 | DOCUMENTED_APPROVED |
| 15 | BH-REQ-015 | Adaptive Risk og Exit | RISK | 08 | P0 | DOCUMENTED_APPROVED |
| 16 | BH-REQ-016 | Advanced Paper og Shadow Execution | PAPER | 09 | P1 | DOCUMENTED_APPROVED |
| 17 | BH-REQ-017 | Scientific Strategy Validation | RESEARCH | 13 | P1 | DOCUMENTED_APPROVED |
| 18 | BH-REQ-018 | Adaptive Evidence Gate | GOV | 13 | P1 | DOCUMENTED_APPROVED |
| 19 | BH-REQ-019 | Controlled Deployment og rollback | OPS | 16 | P1 | DOCUMENTED_APPROVED |
| 20 | BH-REQ-020 | Command Center og Telegram | UI | 11 | P1 | DOCUMENTED_APPROVED |
| 21 | BH-REQ-021 | Secure mobile access | UI | 15 | P2 | DOCUMENTED_APPROVED |
| 22 | BH-REQ-022 | Modulbasert masterplan og QA | ARCH | 00 | P0 | DOCUMENTED_APPROVED |
| 23 | BH-REQ-023 | Nytt selvstendig repository | ARCH | 00 | P0 | DOCUMENTED_APPROVED |
| 24 | BH-REQ-024 | Isolert scanner og 10 optimaliseringer | OPS | 02 | P0 | DOCUMENTED_APPROVED |
| 25 | BH-REQ-025 | Performance og Reliability Foundation | OPS | 02 | P0 | DOCUMENTED_APPROVED |
| 26 | BH-REQ-026 | Supervised Self-Healing | OPS | 02 | P0 | DOCUMENTED_APPROVED |
| 27 | BH-REQ-027 | Advanced Lightweight Observability | OPS | 02 | P0 | DOCUMENTED_APPROVED |
| 28 | BH-REQ-028 | Hybrid Backup og Disaster Recovery | OPS | 16 | P0 | DOCUMENTED_APPROVED |
| 29 | BH-REQ-029 | Fleksibel backup provider kontrakt | OPS | 16 | P1 | DOCUMENTED_APPROVED |
| 30 | BH-REQ-030 | Controlled Update Manager | OPS | 16 | P1 | DOCUMENTED_APPROVED |
| 31 | BH-REQ-031 | GPT routing med budsjett | AI | 10 | P1 | DOCUMENTED_APPROVED |
| 32 | BH-REQ-032 | Full hybrid Qwen API ChatGPT GPT | AI | 10 | P1 | DOCUMENTED_APPROVED |
| 33 | BH-REQ-033 | Secure read-only GPT Gateway | GATEWAY | 11 | P1 | DOCUMENTED_APPROVED |
| 34 | BH-REQ-034 | Advanced Market Intelligence GPT | GATEWAY | 11 | P1 | DOCUMENTED_APPROVED |
| 35 | BH-REQ-035 | Adaptive Context Engine | AI | 10 | P1 | DOCUMENTED_APPROVED |
| 36 | BH-REQ-036 | Hybrid Market Memory | KNOW | 14 | P2 | DOCUMENTED_APPROVED |
| 37 | BH-REQ-037 | Validated Memory Influence | KNOW | 14 | P2 | DOCUMENTED_APPROVED |
| 38 | BH-REQ-038 | Advanced Market Drift Detection | RESEARCH | 14 | P2 | DOCUMENTED_APPROVED |
| 39 | BH-REQ-039 | Autonomous Drift Research | RESEARCH | 14 | P2 | DOCUMENTED_APPROVED |
| 40 | BH-REQ-040 | Adaptive Research Priority | RESEARCH | 12 | P2 | DOCUMENTED_APPROVED |
| 41 | BH-REQ-041 | Research ROI og effectiveness | RESEARCH | 14 | P2 | DOCUMENTED_APPROVED |
| 42 | BH-REQ-042 | Controlled Research Process Optimizer | RESEARCH | 14 | P2 | DOCUMENTED_APPROVED |
| 43 | BH-REQ-043 | Context Budget Engine | AI | 10 | P1 | DOCUMENTED_APPROVED |
| 44 | BH-REQ-044 | Validated Context Compression | AI | 10 | P1 | DOCUMENTED_APPROVED |
| 45 | BH-REQ-045 | Context Quality Benchmark | AI | 10 | P1 | DOCUMENTED_APPROVED |
| 46 | BH-REQ-046 | Model-Aware Context Profiles | AI | 10 | P1 | DOCUMENTED_APPROVED |
| 47 | BH-REQ-047 | Selective Dual Analysis | AI | 10 | P1 | DOCUMENTED_APPROVED |
| 48 | BH-REQ-048 | Human-Guided Strategy Governance | GOV | 13 | P1 | DOCUMENTED_APPROVED |
| 49 | BH-REQ-049 | Critical Strategy Review | GOV | 13 | P1 | DOCUMENTED_APPROVED |
| 50 | BH-REQ-050 | Controlled Disagreement Resolution | GOV | 14 | P2 | DOCUMENTED_APPROVED |
| 51 | BH-REQ-051 | Validated Disagreement Learning | KNOW | 14 | P2 | DOCUMENTED_APPROVED |
| 52 | BH-REQ-052 | Selective Disagreement Memory | KNOW | 14 | P2 | DOCUMENTED_APPROVED |
| 53 | BH-REQ-053 | Unified Knowledge Evidence Architecture | KNOW | 14 | P1 | DOCUMENTED_APPROVED |
| 54 | BH-REQ-054 | Separate Market og Research SQLite | DATA | 05 | P0 | DOCUMENTED_APPROVED |
| 55 | BH-REQ-055 | Tiered Market Data Storage | DATA | 05 | P1 | DOCUMENTED_APPROVED |
| 56 | BH-REQ-056 | Adaptive Data Processing | DATA | 05 | P1 | DOCUMENTED_APPROVED |
| 57 | BH-REQ-057 | Adaptive Backtest Acceleration | RESEARCH | 12 | P2 | DOCUMENTED_APPROVED |
| 58 | BH-REQ-058 | Adaptive Experiment Search | RESEARCH | 12 | P2 | DOCUMENTED_APPROVED |
| 59 | BH-REQ-059 | Multi-Objective Strategy Selection | RESEARCH | 13 | P2 | DOCUMENTED_APPROVED |
| 60 | BH-REQ-060 | Diverse Challenger Portfolio | RESEARCH | 13 | P2 | DOCUMENTED_APPROVED |
| 61 | BH-REQ-061 | Cross-Strategy Risk Intelligence | RISK | 08 | P1 | DOCUMENTED_APPROVED |
| 62 | BH-REQ-062 | Governed Portfolio Risk Control | RISK | 08 | P0 | DOCUMENTED_APPROVED |
| 63 | BH-REQ-063 | Regime-Aware Risk Research | RESEARCH | 14 | P2 | DOCUMENTED_APPROVED |
| 64 | BH-REQ-064 | Multi-Signal Regime Transition | INTEL | 06 | P1 | DOCUMENTED_APPROVED |
| 65 | BH-REQ-065 | Early Regime Opportunity Detection | OPP | 07 | P1 | DOCUMENTED_APPROVED |
| 66 | BH-REQ-066 | Advanced Breakout Readiness | OPP | 07 | P1 | DOCUMENTED_APPROVED |
| 67 | BH-REQ-067 | Calibrated Breakout Probability | RESEARCH | 14 | P2 | DOCUMENTED_APPROVED |
| 68 | BH-REQ-068 | Evidence-Calibrated Ranking | OPP | 14 | P2 | DOCUMENTED_APPROVED |
| 69 | BH-REQ-069 | Intelligent Analysis Selection | AI | 10 | P1 | DOCUMENTED_APPROVED |
| 70 | BH-REQ-070 | Time-Critical Hybrid Routing | AI | 10 | P1 | DOCUMENTED_APPROVED |
| 71 | BH-REQ-071 | Full Architecture Consolidation | ARCH | 00 | P0 | DOCUMENTED_APPROVED |
| 72 | BH-REQ-072 | To byggeagenter med worktrees | DEV | 00 | P0 | DOCUMENTED_APPROVED |
| 73 | BH-REQ-073 | Supervised Dual-Agent Orchestration | DEV | 00 | P0 | DOCUMENTED_APPROVED |
| 74 | BH-REQ-074 | Controlled Continuous Integration | DEV | 00 | P0 | DOCUMENTED_APPROVED |
| 75 | BH-REQ-075 | Risk-Based Cross-Review | DEV | 00 | P0 | DOCUMENTED_APPROVED |
| 76 | BH-REQ-076 | Dependency-Aware Task Scheduler | DEV | 00 | P0 | DOCUMENTED_APPROVED |
| 77 | BH-REQ-077 | Advanced Task Readiness Gate | DEV | 00 | P0 | DOCUMENTED_APPROVED |
| 78 | BH-REQ-078 | Adaptive Task Decomposition | DEV | 00 | P0 | DOCUMENTED_APPROVED |
| 79 | BH-REQ-079 | Dual-Agent Development Efficiency | DEV | 00 | P0 | DOCUMENTED_APPROVED |
| 80 | BH-REQ-080 | Superbyggeagent er eksternt byggesystem | DEV | 00 | P0 | RECONFIRMED |
| 81 | BH-REQ-081 | Klargjør prosjekt/contract-first | ARCH | 01 | P0 | RECONFIRMED |
| 82 | BH-REQ-082 | Bygg på annen PC, kjør på egen disk | DEP | 02 | P0 | RECONFIRMED |
| 83 | BH-REQ-083 | Hardened Application Sandbox | DEP | 02 | P0 | RECONFIRMED |
| 84 | BH-REQ-084 | Portable llama.cpp runtime | AI | 10 | P1 | RECONFIRMED |
| 85 | BH-REQ-085 | Adaptive Model Lifecycle | AI | 10 | P1 | RECONFIRMED |
| 86 | BH-REQ-086 | Hardware-Aware Model Benchmark | AI | 10 | P1 | RECONFIRMED |
| 87 | BH-REQ-087 | Controlled Model Upgrade Pipeline | OPS | 16 | P2 | RECONFIRMED |
| 88 | BH-REQ-088 | Controlled Application Update | OPS | 16 | P1 | RECONFIRMED |
| 89 | BH-REQ-089 | Advanced Disaster Recovery | OPS | 16 | P0 | RECONFIRMED |
| 90 | BH-REQ-090 | Hybrid Backup Providers | OPS | 16 | P0 | RECONFIRMED |
| 91 | BH-REQ-091 | Secure Zero-Touch Installer (foreslått) | DEP | 17 | P1 | PROPOSED_NOT_APPROVED |

**Kontroll:** Alle 91 numre er representert. Steg 91 er *foreslått/ikke godkjent*. Registrerte kildesteg er planleggingsbeslutninger, ikke 91 distinkte runtime-tjenester.
