# Conflict Resolution & Prioritization Register

| Conflict | Earlier alternatives | Final interpretation | Blocker? |
|---|---|---|---|
| Hosting | VPS vs local | LOCAL first; VPS optional later | No |
| Development PC | Local 16GB PC also coder? | Code on OTHER PC; 16GB/8GB PC is target | No |
| Superbyggeagent | New built-in two-agent scheduler vs existing agent builder | Two builder agents already exist; documents only; no runtime orchestration code | No |
| Merge vs fasegate | Continuous CI vs approval per phase | Merge safe tasks continuously WITHIN phase; phase GO remains | No |
| GPT usage | Custom GPT vs API as autonomous actor | ChatGPT Custom GPT user-initiated review, OpenAI API only time-critical automatic decisions | No |
| LLM runtime | Ollama vs Portable llama.cpp | Portable llama.cpp + GGUF first, adapter-based, Ollama optional FUTURE | No |
| Disk isolation | Own drive equals secure sandbox? | NO; Windows identity/ACL/Firewall; not full VM guarantee | No |
| Autonomy | Adaptive production strategy changes vs manual approval | Autonomous research/shadow, never production promotion without user GO | No |
| Knowledge Store | One SQLite vs physical split | Unified logical API, Market/Research separate SQLite + Parquet | No |
| Reliability | Auto restore vs irreversible data migrations | Safe non-destructive self-recovery only; destructive restore requires GO | No |
| Coverage | 100% coverage vs production quality | Separate 100% statement+branch gates and other scenario/security/performance gates | No |
| Step 91 | Secure Zero-Touch Setup proposed | NOT approved; guided installer can be drafted but not silently enabled for privileges | **Decision prior to final install policy** |

Implementasjonsagent skal ved ny konflikt lage en ADR, ikke velge tilfeldig eller skjule avvik. Kritiske sikkerhetssaker stopper berørt task.
