#!/usr/bin/env python3
"""Offline QA for the development SPECIFICATION. This is not runtime code QA."""
import collections, json, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]

def load(rel):return json.loads((ROOT/rel).read_text(encoding='utf8'))

def run():
 errors=[]
 reg=load('requirements/requirements_registry.json')['items']
 tasks=load('tasks/TASK_BACKLOG_V2.json')['tasks']
 if len(reg)!=91:errors.append(f'expected 91 requirements, got {len(reg)}')
 if len(tasks)!=141:errors.append(f'expected 141 tasks, got {len(tasks)}')
 rids={r['requirement_id'] for r in reg}; ids={x['task_id'] for x in tasks}
 if len(rids)!=91:errors.append('duplicate requirement id')
 if len(ids)!=len(tasks):errors.append('duplicate task id')
 for n in range(1,92):
  if f'BH-REQ-{n:03}' not in rids:errors.append(f'missing requirement {n}')
 r91=next((r for r in reg if r['requirement_id']=='BH-REQ-091'),{})
 if r91.get('decision_status')!='PROPOSED_NOT_APPROVED':errors.append('91 may NOT be marked approved')
 trace=(ROOT/'requirements/TRACEABILITY_01_91.md').read_text(encoding='utf8')
 for n in range(1,92):
  if f'BH-REQ-{n:03}' not in trace:errors.append(f'traceability missing requirement {n}')
 phases={f'{x:02}' for x in range(18)}
 if {t['phase'] for t in tasks}!=phases:errors.append('missing phase tasks')
 pmap={t['task_id']:t for t in tasks}
 paths=collections.defaultdict(list)
 for t in tasks:
  tid=t['task_id'];deps=t['depends_on']
  if not (ROOT/t['task_card']).is_file():errors.append(f'missing card: {tid}')
  if not t['write_set']:errors.append(f'missing write_set: {tid}')
  if len(t['write_set'])!=len(set(t['write_set'])):errors.append(f'duplicate write paths within {tid}')
  for x in t['write_set']:
   if x.startswith('/') or '..' in pathlib.PurePosixPath(x).parts:errors.append(f'unsafe write path {tid}: {x}')
   paths[x].append(tid)
  for d in deps:
   if d not in ids:errors.append(f'unknown dep {tid}->{d}')
   if d==tid:errors.append(f'self-dep {tid}')
  if not t['concrete_positive_oracle'] or not t['concrete_negative_oracle']:errors.append(f'missing oracle {tid}')
  if len(t['requirements'])==0:errors.append(f'no requirements for {tid}')
  for r in t['requirements']:
   if r not in rids:errors.append(f'unknown requirement {r} in {tid}')
 # Dependencies can be shared paths if sequential, but do not permit overlap in concurrent-ready tasks.
 def ancestor(node, target, seen=None):
  seen=set() if seen is None else seen
  if node==target:return True
  if node in seen:return False
  seen.add(node)
  return any(ancestor(d,target,seen) for d in pmap[node]['depends_on'] if d in pmap)
 for path,owners in paths.items():
  if len(owners)>1:
   for i,a in enumerate(owners):
    for b in owners[i+1:]:
     if not(ancestor(a,b) or ancestor(b,a)):
      errors.append(f'concurrent write overlap {path}: {a},{b}')
 # Topological sort
 todo={t['task_id']:set(t['depends_on']) for t in tasks};ready=[];visited=set()
 while todo:
  avail={tid for tid,deps in todo.items() if deps<=visited}
  if not avail:
   errors.append('DAG cycle/deadlock '+str({k:list(v-visited) for k,v in list(todo.items())[:6]}));break
  ready.append(len(avail));visited.update(avail)
  for k in avail:todo.pop(k)
 # V2/legacy strong distinction
 if 'TASK_BACKLOG_V2.json' not in (ROOT/'AGENTS.md').read_text():errors.append('AGENTS.md not V2-first')
 if errors:
  print('FAIL SPEC PACKAGE:',len(errors))
  for e in errors[:40]:print(' -',e)
  return 1
 print(f'PASS SPEC PACKAGE: {len(reg)} requirements, {len(tasks)} task cards, 18 phases, no DAG cycles or concurrent file conflicts')
 print('DAG levels:',len(ready),'max ready per level:',max(ready))
 return 0
if __name__=='__main__':sys.exit(run())
