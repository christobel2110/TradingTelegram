# PHASE 10: Portable Hybrid AI & Usage

**Mål:** Local llama.cpp, cloud fallback and context optimization.

**Inngang:** Fase 09 godkjent med faktisk CI-evidence og GO.

**Relevant kildesteg:** BH-REQ-010, BH-REQ-031, BH-REQ-032, BH-REQ-035, BH-REQ-043, BH-REQ-044, BH-REQ-045, BH-REQ-046, BH-REQ-047, BH-REQ-069, BH-REQ-070, BH-REQ-084, BH-REQ-085, BH-REQ-086

## Ferdigdefinerte kodeoppgaver (kan fordeles mellom 2 agenter)

### BH-10-01 — Integrate portable llama.cpp runtime
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Approved binary/model hash, CPU/GPU loopback.

**Negativt akseptansekriterium:** No runtime needs admin after setup.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/ai/integrate_portable_llama_cpp_runtime*`, `backend/tests/ai/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-10-02 — Implement hardware-aware model benchmark
**Forslag eier:** agent_b · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** Qwen 2-4B Q4 profile, lat/VRAM/quality.

**Negativt akseptansekriterium:** Select only model under safe target margin.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/ai/implement_hardware_aware_model_benchmark*`, `backend/tests/ai/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-10-03 — Implement model lifecycle and resource guard
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Load/unload/cooldown/bounded queue, CPU fallback.

**Negativt akseptansekriterium:** No scanner blocking on model.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/ai/implement_model_lifecycle_and_resource_g*`, `backend/tests/ai/*`.

**Avhengigheter:** BH-10-01.

### BH-10-04 — Implement OpenAI API adapter
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Approved IDs, timeouts, structured schema, source-of-truth evidence.

**Negativt akseptansekriterium:** No invented prices in result mapping.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/ai/implement_openai_api_adapter*`, `backend/tests/ai/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-10-05 — Implement API cost and rate budget guard
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Reserve worst case then reconcile usage with fallback.

**Negativt akseptansekriterium:** Concurrent calls cannot exceed configured cap.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/ai/implement_api_cost_and_rate_budget_guard*`, `backend/tests/ai/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-10-06 — Implement model-aware L1 L2 L3 context
**Forslag eier:** agent_b · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** Qwen/API/GPT profiles, fresh data/pruned irrelevant.

**Negativt akseptansekriterium:** No critical risk field removed.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/ai/implement_model_aware_l1_l2_l3_context*`, `backend/tests/ai/*`.

**Avhengigheter:** BH-10-01.

### BH-10-07 — Implement validated compression benchmark
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Compare fact retention decisions tokens latency.

**Negativt akseptansekriterium:** Any critical numeric change fails.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/ai/implement_validated_compression_benchmar*`, `backend/tests/ai/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-10-08 — Implement selective time-critical routing
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** NO_AI local API conditional and deadline flags.

**Negativt akseptansekriterium:** Expired candidate does not trigger delayed paid call.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/ai/implement_selective_time_critical_routin*`, `backend/tests/ai/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-10-09 — Phase 10 AI fault and cost acceptance
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** No AI/OOM/JSON invalid/API failure stress.

**Negativt akseptansekriterium:** Scanner continues under all tested AI failure modes.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/ai/phase_10_ai_fault_and_cost_acceptance*`, `backend/tests/ai/*`.

**Avhengigheter:** BH-10-01, BH-10-02, BH-10-03, BH-10-04, BH-10-05, BH-10-06, BH-10-07, BH-10-08.

## Exit Gate
- Alle tasks PASS på eksakt merge commit.
- Statement og branch coverage kontrollert separat.
- Kritiske negative scenariotester, security scan og evt Windows mål-PC tester PASS.
- Release/testevidence og dokumentasjon oppdatert.
- Bruker GO før neste fase.
