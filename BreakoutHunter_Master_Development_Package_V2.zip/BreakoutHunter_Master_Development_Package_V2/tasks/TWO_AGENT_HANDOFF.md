# To-agent handoff uten ny orchestration runtime

Dette er **dokumenter for eksisterende Superbyggeagent**. Agent A/B eier forskjellige tasks, aldri samme skrivefil samtidig. Det er IKKE et krav at BreakoutHunter implementerer egne task-schedulers, efficiency engines eller code-review agenter.

## Parallellismekontrakt
- Phase 00/01 contracts etablerer felles schemas. Etter det kan A/B implementere separate filbaner med frozen fixtures.
- Task `owner_hint` er bare forslag: Superbyggeagenten kan flytte oppgave mellom agentene om eksklusive fil-leases og DAG respekteres.
- Agentene skal kjøre isolerte Git worktrees, egne branches, env/venv, process quota, nettverkspolicy og secrets (ingen produksjonsnøkler).
- `allowed_paths_hint` er forslag til sprint; det operative `file_lease_manifest` må inneholde **eksakte filer** før task start, for å hindre kollisjon innenfor folder-globs.
- Hver task har `depends_on`, fase-prerequisite, model tier, acceptance, test plan; integration task er avhengig av alle øvrige faseoppgaver.
- Reviewer på HIGH må være uavhengig, merges bak beskyttede status checks; ingen self-approval.

## Effektivitetsmål
Mål approved milestones/wall clock time og usage where available. Dersom 2 agenter dobler rework/usage, smal inn parallellitet. Ikke tving samtidighet når bare én uavhengig task finnes.

## Sikkerhetsgrenser for builder (runtime ikke implementert her)
Separat filesystem checkout/venv/temp; deny credential env; scoped network; OS-level process identity med begrenset CPU/RAM/disk når støttet; unngå direkte write i production target disk. Agentene må ikke ha API keys, traderettigheter eller tilgang til signing key.
