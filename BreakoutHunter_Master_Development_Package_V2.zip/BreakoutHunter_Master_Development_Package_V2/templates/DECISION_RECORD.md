# Architecture Decision Record TEMPLATE

- ADR_ID:
- Status: PROPOSED | APPROVED | REJECTED | SUPERSEDED
- Requested-by / approved-by:
- Date:
- Related requirements:
- Problem and constraints:
- Options with tradeoffs:
- Selected solution / reason:
- Threats and risks:
- Impact on contracts/phase/task ownership:
- Verification/evidence (links + versions):
- Rollback/exit criteria:
