# PHASE 09: Paper, Shadow & Telegram MVP

**Mål:** Traceable trade simulation and safe alerts.

**Inngang:** Fase 08 godkjent med faktisk CI-evidence og GO.

**Relevant kildesteg:** BH-REQ-016

## Ferdigdefinerte kodeoppgaver (kan fordeles mellom 2 agenter)

### BH-09-01 — Implement paper order lifecycle
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Market limit stop partial/cancel/expire event model.

**Negativt akseptansekriterium:** No fill before order time.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/paper/implement_paper_order_lifecycle*`, `backend/tests/paper/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-09-02 — Implement conservative fill/slippage model
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Spread depth latency, no perfect fills with insufficient data.

**Negativt akseptansekriterium:** Missing depth => uncertainty or no fill.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/paper/implement_conservative_fill_slippage_mod*`, `backend/tests/paper/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-09-03 — Implement fees funding margin simulation
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D3_Critical

**Leveranse:** Mark/last, isolated liquidation and cost accounting.

**Negativt akseptansekriterium:** Funding correctly accrues with clock and rate.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/paper/implement_fees_funding_margin_simulation*`, `backend/tests/paper/*`.

**Avhengigheter:** BH-09-01.

### BH-09-04 — Implement event-sourced paper ledger
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** PnL/positions/MAE/MFE/restart replay.

**Negativt akseptansekriterium:** Replay identity and no double fills.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/paper/implement_event_sourced_paper_ledger*`, `backend/tests/paper/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-09-05 — Implement isolated shadow books
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Independent strategy virtual state on shared candles.

**Negativt akseptansekriterium:** No cross-book position mutations.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/paper/implement_isolated_shadow_books*`, `backend/tests/paper/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-09-06 — Implement Telegram durable outbox and dedup
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Watch/armed/confirmed/review alerts with idempotency.

**Negativt akseptansekriterium:** Timeout does not lose committed alert.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/paper/implement_telegram_durable_outbox_and_de*`, `backend/tests/paper/*`.

**Avhengigheter:** BH-09-01.

### BH-09-07 — Implement limited Telegram read commands
**Forslag eier:** agent_a · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** /top /status /research /pause-research only authorized.

**Negativt akseptansekriterium:** Unknown chat cannot mutate anything.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/paper/implement_limited_telegram_read_commands*`, `backend/tests/paper/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-09-08 — Phase 09 MVP field demo
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** One Spot and one futures paper path, failure scenarios.

**Negativt akseptansekriterium:** No market-writing API rights.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/paper/phase_09_mvp_field_demo*`, `backend/tests/paper/*`.

**Avhengigheter:** BH-09-01, BH-09-02, BH-09-03, BH-09-04, BH-09-05, BH-09-06, BH-09-07.

## Exit Gate
- Alle tasks PASS på eksakt merge commit.
- Statement og branch coverage kontrollert separat.
- Kritiske negative scenariotester, security scan og evt Windows mål-PC tester PASS.
- Release/testevidence og dokumentasjon oppdatert.
- Bruker GO før neste fase.
