# PHASE 01: Canonical Contracts

**Mål:** Version all shared interfaces before parallel code.

**Inngang:** Fase 00 godkjent med faktisk CI-evidence og GO.

**Relevant kildesteg:** BH-REQ-081

## Ferdigdefinerte kodeoppgaver (kan fordeles mellom 2 agenter)

### BH-01-01 — Define primitive types and timestamps
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** UTC time, DecimalString, instrument/market identifiers and quality enums.

**Negativt akseptansekriterium:** Reject naive datetime, overflow and invalid decimals.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/core/define_primitive_types_and_timestamps*`, `backend/tests/core/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-01-02 — Define market contracts
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Instrument, Candle, Snapshot with closed-candle semantics.

**Negativt akseptansekriterium:** Spot/futures never silently merged.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/core/define_market_contracts*`, `backend/tests/core/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-01-03 — Define signal and evidence contracts
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D3_Critical

**Leveranse:** SMC/Fib/regime, BreakoutCandidate, OpportunityAssessment.

**Negativt akseptansekriterium:** Cannot confirm with future pivot or open candle.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/core/define_signal_and_evidence_contracts*`, `backend/tests/core/*`.

**Avhengigheter:** BH-01-01.

### BH-01-04 — Define entry and portfolio risk contracts
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D3_Critical

**Leveranse:** EntryPlan, RiskDecision, PaperOrder/Fill/Position.

**Negativt akseptansekriterium:** Invalid stops and LIVE enum always fail.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/core/define_entry_and_portfolio_risk_contract*`, `backend/tests/core/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-01-05 — Define research and governance contracts
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** ResearchExperiment, ValidationReport, Evidence, Approval and hashes.

**Negativt akseptansekriterium:** Unvalidated evidence cannot promote champion.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/core/define_research_and_governance_contracts*`, `backend/tests/core/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-01-06 — Define read-only GPT API contract
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** OpenAPI GET schemas, pagination, auth, no mutable endpoints.

**Negativt akseptansekriterium:** POST approve/orders rejected.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/core/define_read_only_gpt_api_contract*`, `backend/tests/core/*`.

**Avhengigheter:** BH-01-01.

### BH-01-07 — Build cross-contract golden fixtures and compatibility tests
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Versioned JSON fixtures + consumer driven tests.

**Negativt akseptansekriterium:** Schema version breaks require explicit migration plan.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/core/build_cross_contract_golden_fixtures_and*`, `backend/tests/core/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-01-08 — Phase 01 contract acceptance
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Run tests on provider/consumer fixtures from both worktrees.

**Negativt akseptansekriterium:** Contract divergence blocks next phase.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/core/phase_01_contract_acceptance*`, `backend/tests/core/*`.

**Avhengigheter:** BH-01-01, BH-01-02, BH-01-03, BH-01-04, BH-01-05, BH-01-06, BH-01-07.

## Exit Gate
- Alle tasks PASS på eksakt merge commit.
- Statement og branch coverage kontrollert separat.
- Kritiske negative scenariotester, security scan og evt Windows mål-PC tester PASS.
- Release/testevidence og dokumentasjon oppdatert.
- Bruker GO før neste fase.
