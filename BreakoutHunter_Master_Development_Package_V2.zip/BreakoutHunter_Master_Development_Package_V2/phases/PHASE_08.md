# PHASE 08: Risk & Entry Policy

**Mål:** Fail-closed risk engine, no live orders.

**Inngang:** Fase 07 godkjent med faktisk CI-evidence og GO.

**Relevant kildesteg:** BH-REQ-014, BH-REQ-015, BH-REQ-061, BH-REQ-062

## Ferdigdefinerte kodeoppgaver (kan fordeles mellom 2 agenter)

### BH-08-01 — Implement structural entry and invalidation
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Breakout retest pullback with objective entry/stop.

**Negativt akseptansekriterium:** Wrong stop direction BLOCK.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/risk/implement_structural_entry_and_invalidat*`, `backend/tests/risk/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-08-02 — Implement targets and cost-adjusted RR
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Fib/liquidity TP1-TP3, fees, spread, funding.

**Negativt akseptansekriterium:** Invalid RR or cost data BLOCK.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/risk/implement_targets_and_cost_adjusted_rr*`, `backend/tests/risk/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-08-03 — Implement position size & isolated margin math
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D3_Critical

**Leveranse:** Decimal tick/step and stop risk, liquidation check.

**Negativt akseptansekriterium:** Rounded quantity never exceeds hard cap.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/risk/implement_position_size_isolated_margin_*`, `backend/tests/risk/*`.

**Avhengigheter:** BH-08-01.

### BH-08-04 — Implement cross-strategy exposure aggregator
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Net/gross, correlated clusters, stress loss.

**Negativt akseptansekriterium:** Shadow alternatives not double-counted.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/risk/implement_cross_strategy_exposure_aggreg*`, `backend/tests/risk/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-08-05 — Implement governed ALLOW REDUCE BLOCK HALT
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Versioned immutable hard risk policy.

**Negativt akseptansekriterium:** Missing/stale data => BLOCK/HALT.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/risk/implement_governed_allow_reduce_block_ha*`, `backend/tests/risk/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-08-06 — Implement regime-aware risk research interface
**Forslag eier:** agent_b · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** Only proposes reductions and pause in shadow.

**Negativt akseptansekriterium:** No auto risk raise beyond hard caps.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/risk/implement_regime_aware_risk_research_int*`, `backend/tests/risk/*`.

**Avhengigheter:** BH-08-01.

### BH-08-07 — Property-based and adversarial risk tests
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D3_Critical

**Leveranse:** Boundaries/precision/concurrent risk state transitions.

**Negativt akseptansekriterium:** 0 critical invalid risks accepted.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/risk/property_based_and_adversarial_risk_test*`, `backend/tests/risk/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-08-08 — Phase 08 security freeze
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D3_Critical

**Leveranse:** Negative network test proves no live order code.

**Negativt akseptansekriterium:** No credential necessary for risk engine.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/risk/phase_08_security_freeze*`, `backend/tests/risk/*`.

**Avhengigheter:** BH-08-01, BH-08-02, BH-08-03, BH-08-04, BH-08-05, BH-08-06, BH-08-07.

## Exit Gate
- Alle tasks PASS på eksakt merge commit.
- Statement og branch coverage kontrollert separat.
- Kritiske negative scenariotester, security scan og evt Windows mål-PC tester PASS.
- Release/testevidence og dokumentasjon oppdatert.
- Bruker GO før neste fase.
