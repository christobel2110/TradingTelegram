# Source Provenance — verifisert mot offentlig dokumentasjon 2026-10-19

Denne filen dokumenterer **hvilke offentlige kilder ble funnet**, ikke at vi har kjørt brukerens PC eller testet en integrasjon.

| Emne | Offisiell dokumentasjon | Hva den støtter | Fortsatt ikke verifisert |
|---|---|---|---|
| BingX Spot WS | https://github.com/BingX-API/api-ai-skills/blob/main/skills/spot-ws-market/api-reference.md | public Spot market WS, gzip, ping/pong | individuelle symb/limits/status ved utrulling |
| BingX Swap WS | https://github.com/BingX-API/api-ai-skills/blob/main/skills/swap-ws-market/api-reference.md | public futures WS, gzip, ping/pong | full REST/funding/OI/symbol støtte per marked |
| llama.cpp Windows | https://github.com/ggml-org/llama.cpp/releases | Windows CPU og CUDA artifacts | driver/ABI/variant på mål-PC, valgt release hash |
| GPT Actions | https://help.openai.com/en/articles/9442513-gpt-actions-domain-settings-chatgpt-enterprise | OpenAPI+auth og workspace restrictions | GPT Actions aktiv i brukerens GPT/plan/workspace |
| OpenAI Model Selection | https://developers.openai.com/api/docs/guides/model-selection | task-based model family recommendation | brukerens tilgjengelige Codex/ChatGPT/API modeller |
| OpenAI API Models | https://developers.openai.com/api/docs/models | akt. modellkatalog/ID | kontotilgang og rate limits |
| OpenAI Pricing | https://developers.openai.com/api/docs/pricing | publiserte API priser kan verifiseres | fremtidige priser, faktisk usage/billing |
| Prompt Caching | https://developers.openai.com/api/docs/guides/prompt-caching | gjenbruk av stabilt prefix, caching betinget | faktisk cache hit rate |
| Structured Outputs | https://developers.openai.com/api/docs/guides/structured-outputs | schema begrenser format | faktanøyaktighet/risiko utover schema |

Ingen versjoner for Python, Polars, PyArrow, FastAPI, llama.cpp eller GGUF blir gjettet. De skal låses i `DEPENDENCY_LOCK` etter faktisk integrasjons- og sikkerhetsbenchmark, med kilde, hash, lisens og tested-on-matrix.
