# Model & Usage Policy — Superbyggeagent + BreakoutHunter

## To uavhengige budsjetter
**Development usage** (Codex / Superbyggeagentens to agenter): ChatGPT/Codex-produktets usage er ikke nødvendigvis identisk med API-tokens; måles i faktisk tilgjengelig produkttelemetri. Ingen ubegrunnet prosentbesparelse.
**Runtime OpenAI API**: separate fakturerte API-kall for tidskritiske kandidater og Research (to underbudsjetter). Din egendefinerte GPT i ChatGPT går gjennom app-produktets grenser, ikke automatisk runtime API-budsjett.

## Modellruting under utvikling
| Klassetype | Oppgave | Førstevalg | Eskaler bare hvis |
|---|---|---|---|
| D0 | docs, YAML sortering, formattering, enkle tester | lokalt deterministisk verktøy eller tilgjengelig rask/lett modell (f.eks. Luna Low) | tester krever ny analyse |
| D1 | begrenset implementering med godkjent kontrakt | tilgjengelig Sol/Medium-nivå eller lett modell hvis evals beviser tilstrekkelig | regresjonsfeil / kompleks avhengighet |
| D2 | WebSocket concurrency, Windows hardening, event journal, contracts | høy reasoning i kvalifisert tilgjengelig modell | avvik/feil krever sikkerhetsrevisjon |
| D3 | risk gates, signing, secure updater, crypto, statistical leakage | sterkeste tilgjengelige kvalifiserte modell med High/Extra High og uavhengig review | bruk billigere kun etter objektiv benchmark |

**Konkret modellvalget skal ikke hardkodes**: tilgjengelighet varierer etter abonnement, klient/CLI og produkt. Offisiell katalog (2026-10-19) beskriver Astra = mest krevende, Sol = balanse, Luna = kostnadseffektiv; dette er *anbefalingsfamilier*, ikke påstand om at bruker har tilgang. Synkroniser `models/approved_models.yaml` ved faktisk kjøring og lagre adapter/mapping.

## Minimum kontekst per Codex task
Kjør `task_readiness`: TASK id, kontraktversjon, 1-3 aktuelle krav, relevant diff / filer, testfixtures, sikkerhetsregler, tidligere feil. Les hele repo bare når cross-module review krever det. Lokale QA-resultater er 1 side summary + link til rålogger. Dedupe gamle feil, ikke rerun samme prompt, etter to identiske reparasjonsfeil: ny root cause/plan.

## Runtime AI seleksjon
NO_AI -> Qwen lokal når ledig -> OpenAI API for prioriterte sterke/konfliktfylte/time-critical hvor verdi og kostnad kan begrunnes. **ChatGPT GPT er interaktiv reviewer** for ikke-tidskritiske strategibeslutninger. Ikke automatisk double-charge forskningsrapporter via API før bruker-GPT review.

## OpenAI API routing og budget
- Hent katalog og pris ved implementasjon; valider ID/reasoning effort per modell. Konfigurer kun approved IDs.
- Call eligibility: fresh evidence, finite deadline, expected decision impact, fresh model/prompt version, no prior identical context hash, budget reservation.
- Før kall reserver worst-case output/input-pris og optional buffer, etterpå reconcile mot faktisk rapportert `usage`. Når usage/pris ukjent: BLOCK og returner rule-based summary. Hard daily cap, forskningscap og rate limit.
- `fast` er vanligvis færre tokens, `deep` kun når eval viser forbedring. Prompts med stabilt prefix for caching; ikke hev at caching er garantert. Fast JSON schema for output og deterministisk verifikasjon av kritiske facts.
- Local llama.cpp GGUF eval: test 2-4B Q4 class first, 7-8B kun hvis målt ressursmargin/latency og kvalitet slår kandidat. Hard resource gates, on-demand unload, CPU fallback.

## Kvalitet/kost modellbenchmark
Benchmark samme *frosne* 100+ relevante cases (normale, no-trade, illiquid, contradictory, malformed, risk, statistics, hallucination prompts) på modeller som faktisk er tilgjengelige; blind judge + deterministisk schema/fact checks. Mål: critical error rate 0 i suite, correct decisions, invalid JSON, P50/P95 response, input/output/cached tokens, cost per valid decision, local RAM/VRAM. Gjenta og rapporter usikkerhet, velg Pareto-effektiv modell som består minimumsgater. Kjør det ved førstevalg og ved større modellendring.

## Kildedata (kontrollert 2026-10-19)
- https://developers.openai.com/api/docs/guides/model-selection — anbefalinger etter oppgave, ikke tilgangsgaranti.
- https://developers.openai.com/api/docs/models — modell-ID/tilgjengelighet må bekreftes i faktisk konto.
- https://developers.openai.com/api/docs/pricing — priser endres; ikke bruk tall fra planleggingssimulator som live pris.
- https://developers.openai.com/api/docs/guides/prompt-caching — caching er betinget, stable prefix prioritet.
- https://developers.openai.com/api/docs/guides/structured-outputs — schema-validering.
