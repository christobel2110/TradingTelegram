# Executable Golden Fixtures & Independent Test Oracles

## Kontraktskontroll
- JSON Schema Draft 2020-12 under `contracts/jsonschema/`, representative fixtures in `contracts/fixtures/valid/` and intentionally invalid fixtures in `contracts/fixtures/invalid/`.
- `python scripts/validate_contract_fixtures.py` validates positive fixtures and asserts rejection of every negative case; failing to reject is FAIL.
- `contracts/canonical_models.yaml` is the functional DTO catalog; `contracts/jsonschema/` is normative for JSON wire format. Non-JSON semantic requirements must be tested in typed code (decimal rounding, OHLC bounds, point-in-time, causal sequencing, risk caps).

## Required high-risk independent oracles
| Oracle | Input | Expected invariant |
|---|---|---|
| Price rounding | tick=.01, step=.001, side=LONG/SHORT | risk never exceeds cap due to rounding |
| Candle OHLC | open=100 high=99 low=98 close=100 | reject invalid H/O/L/C despite parse-valid schema |
| Closed candle | is_closed=false, breakout over threshold | no CONFIRMED regardless of score |
| Future pivot | rightbars=3, last bar only 2 available | pivot remains pending, cannot appear in backtest |
| WebSocket order | 3 events shuffled; 1 duplicate | normalized chronology and exactly one persistent event per ID |
| Restart after outbox write | crash before Telegram ack | outbox replay, no duplicate signal state; external notification may duplicate |
| Risk math | stop equals entry / null tick | BLOCK, never division by zero |
| Paper fills | market crosses TP and SL inside same OHLC bar | conservative ambiguous result, not invented win |
| Probabilities | horizon label not matured | CENSORED, not 0/1 arbitrarily |
| GPT gateway | unauthed, stale, oversized context | 401/503/413 or safe validated bounded response |
| Model selection | 8GB VRAM shared with desktop, 4B too large | fallback; never take scanner down |
| Database restore | corrupted payload or lost recovery key | NO destructive restore; retain original |

## V2 fixture records
File basename maps to model name; invalid fixtures are *contract violations*, not market scenarios. Market semantic tests (e.g., OHLC order, price tick) must be separately executed by codeagent and linked to the task card. Every market fixture has an as-of timestamp – do not reinterpret an old example as current data.

## Acceptance pass/fail
Schema PASS is necessary but insufficient. For critical tasks: parser PASS, semantic validator PASS, fault/integration PASS, package + CI PASS, measured on target hardware where required. No false claims of actual BingX connection or model performance.
