# Scope, prioritet og konfliktregel

## P0 — blocker for trygg produksjonslignende drift
Kontrakter, read-only, sikker installasjon, dataintegritet, risikogates, fysiske sandboxgrenser, kritisk hendelsesjournal, kvalitet/CI og backup-fundament. Må bygges/testes før respektive P1 leveranser aktiveres. **P0 angir kravkritikalitet, ikke bare en implementasjonsfase**.

## P1 — operativ v1
Markedsdata, breakout-signaler, deterministisk risiko og paper, Telegram, lokal hybrid AI, GPT Gateway, enkel research, portable release.

## P2 — etter verifisert grunnsystem
Advanced probability, dynamic memory influence, selvoptimalisering, detaljert research ROI, model-upgrade, komplisert challenger-portefølje og mobil avansert.

## Beslutningsregler
- `PROPOSED_NOT_APPROVED`: kan spesifiseres som opsjon, men ikke tvinges på brukeren.
- Er ny idé i konflikt med godkjent read-only/sandbox/risikopolicy: blokker og registrer beslutningssak.
- Tverrfase P0 må implementeres senest når tilhørende risiko introduseres, selv om hovedmodulen har senere fase.
- Ikke bygg ekstern Superbyggeagent-orkestrator på nytt i denne appen.
- Ingen påstand om 24/7 når Windows-maskinen er av.
