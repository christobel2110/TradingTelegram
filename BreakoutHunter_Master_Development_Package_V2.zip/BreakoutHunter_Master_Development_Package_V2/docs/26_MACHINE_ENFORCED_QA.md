# Machine-Enforced Quality Gates – akseptanseregler

## Krav per merge (ingen selvrapportert PASS)
- Valider låste avhengigheter, lint/format, typecheck, kontraktsfixture, pytest unit/integration og relevante negative faults.
- 100% statement **OG separat** 100% branch for egen kritisk produksjonskode. Dekningsgrunnlaget (`include` paths), eventuelle unntak og branch-totaler må følge manifest. Ukjent/0 branch-totalt teller **ikke** som bestått branch-gate uten særskilt kode-review.
- Koble råtestlogger, testkommando, avhengighetslås, OS/runtime og dekning til nøyaktig `commit_sha` og `merge_sha`. Artefakter lagres under `reports/evidence/<task_id>/<sha>/`.
- PR/merge-regler: beskyttet `main`, påkrevde statuschecks, review for HIGH, ingen tillatt bypass for agenttoken, og gjenkjør/merge-queue på endret head. Kontroller faktisk repo-administrasjon før du hevder håndheving.
- Ved ny kritisk feil: fail closed; ingen «manual PASS» uten nye tekniske bevis.

## Output template (bevis, ikke designpåstand)
```
TASK_ID: BH-XX-YY
COMMIT_SHA: <40 hex>
MERGE_SHA: <40 hex or PENDING>
SCOPE_HASH: <sha256 of release/coverage manifest>
STATEMENTS: covered=N total=N pct=100.00
BRANCHES: covered=N total=N pct=100.00
TEST_COMMANDS: [...] (real exit codes)
INTEGRATION: PASS/FAIL
SECURITY: PASS/FAIL
PERFORMANCE: PASS/FAIL/NOT_APPLICABLE
REVIEW: reviewer id, report sha
PHASE_APPROVAL: authorized user / PENDING
```

## Ikke-forhandlingsbare negative prøver
1. Ingen ekte BingX order-endpoint finnes i runtime/egress-allowlist.
2. GPT Gateway kan aldri skrive, promosiere strategi, starte prosess eller lese secrets.
3. Risk Gate `HALT/BLOCK` kan ikke overskrides ved ugyldige data.
4. Paper/shadow må aldri konstruere exchange orders.
5. Ingen fremtidsinformasjon i pivot/SMC og historiske backtests.
6. Restore/migrering og signerte updater er fail-closed under korrupt disk/hash.

Disse må implementeres og demonstreres, ikke bare omtales i dokumentasjonen.
