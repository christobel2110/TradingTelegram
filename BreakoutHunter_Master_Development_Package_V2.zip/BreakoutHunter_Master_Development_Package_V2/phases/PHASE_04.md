# PHASE 04: BingX Public Feeds & Discovery

**Mål:** Real market data without trading credentials.

**Inngang:** Fase 03 godkjent med faktisk CI-evidence og GO.

**Relevant kildesteg:** BH-REQ-011

## Ferdigdefinerte kodeoppgaver (kan fordeles mellom 2 agenter)

### BH-04-01 — Validate BingX spot/swap public API profiles
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Version endpoints/channels, access and rate-limit evidence.

**Negativt akseptansekriterium:** No speculative endpoint invoked without verification.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/market_data/validate_bingx_spot_swap_public_api_prof*`, `backend/tests/market_data/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-04-02 — Implement Spot REST data adapter
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Bootstrap candles/instruments; retry and parser bounds.

**Negativt akseptansekriterium:** Truncated/invalid payload rejected.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/market_data/implement_spot_rest_data_adapter*`, `backend/tests/market_data/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-04-03 — Implement Futures REST data adapter
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Instrument specifications, candles and optional OI/funding availability.

**Negativt akseptansekriterium:** Missing optional fields stay NULL.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/market_data/implement_futures_rest_data_adapter*`, `backend/tests/market_data/*`.

**Avhengigheter:** BH-04-01.

### BH-04-04 — Implement Spot and Futures WebSocket adapters
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** GZIP/Ping/Pong, normalized frames, bounded subscription count.

**Negativt akseptansekriterium:** Reconnect and heartbeat tests.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/market_data/implement_spot_and_futures_websocket_ada*`, `backend/tests/market_data/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-04-05 — Implement gap detection and backfill
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Candle watermarks, REST reconciliation and stale status.

**Negativt akseptansekriterium:** Gap blocks closed-candle signal.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/market_data/implement_gap_detection_and_backfill*`, `backend/tests/market_data/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-04-06 — Implement historical coin universe discovery
**Forslag eier:** agent_b · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** Light full universe volume/spread/active instrument shortlist.

**Negativt akseptansekriterium:** No illiquid/delisted symbol to deep scanner.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/market_data/implement_historical_coin_universe_disco*`, `backend/tests/market_data/*`.

**Avhengigheter:** BH-04-01.

### BH-04-07 — Implement cross-market instrument normalization
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** No spot/futures bleed; mark and reference prices distinct.

**Negativt akseptansekriterium:** Same symbol in two markets gets distinct ID.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/market_data/implement_cross_market_instrument_normal*`, `backend/tests/market_data/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-04-08 — Phase 04 live-feed integration acceptance
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Fixture + controlled public endpoint smoke test.

**Negativt akseptansekriterium:** No order routes reachable from market-only account.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/market_data/phase_04_live_feed_integration_acceptanc*`, `backend/tests/market_data/*`.

**Avhengigheter:** BH-04-01, BH-04-02, BH-04-03, BH-04-04, BH-04-05, BH-04-06, BH-04-07.

## Exit Gate
- Alle tasks PASS på eksakt merge commit.
- Statement og branch coverage kontrollert separat.
- Kritiske negative scenariotester, security scan og evt Windows mål-PC tester PASS.
- Release/testevidence og dokumentasjon oppdatert.
- Bruker GO før neste fase.
