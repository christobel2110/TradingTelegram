# Traceability — beslutning → fase → oppgaver → testbevis

**Autoritativ:** `requirements/requirements_registry.json` er beslutningshistorikk; `tasks/TASK_BACKLOG_V2.json` er utførelsesplan. Dette dokumentet produseres av oppgavekartleggingen. Det er ikke dokumentasjon på implementert kode.

## Sporbarhetsregler
- Kravene `BH-REQ-001` ... `BH-REQ-091` er representert; siste (`091`) er **PROPOSED_NOT_APPROVED**. Ingen automatisk godkjenning av alternativ B for steg 91.
- En oppgave kan spore flere krav; hvert godkjente krav må ha minst én tilknyttet oppgave eller begrunnet dokumentasjonsregel. Krav kan behandles av en design-/valideringsoppgave før implementasjon.
- `task_id` og `requirements[]` skal aldri endres i stillhet. Endringer krever ADR og regenerert kravdekning.
- Oppgave `DONE` betyr integrert med korrekt SHA, ikke at agenten har skrevet «ferdig».
- Fase 00 er eneste fase med starttillatelse. Fase 01+ krever separat `y` og alle fasegater.

## Særskilt om tidligere 91 valg
Mange valg er varianter av samme funksjon, ikke 91 separate tjenester. Krav for ekstern Superbyggeagent (to kodeagenter, arbeidsfordeling, review, usage) spesifiseres som byggeinstruksjoner i `AGENTS.md`, ikke runtime-funksjoner i BreakoutHunter. Portabel runtime og herdet applikasjon er mål, men ikke full VM-/OS-isolasjon.
