#!/usr/bin/env python3
"""Eksempel: fail-closed coverage-gate, separate statement and branch checks."""
import argparse
import json
from pathlib import Path

def evaluate(payload: dict) -> tuple[bool, str]:
    totals = payload.get("totals", {})
    required = ("num_statements", "covered_lines", "num_branches", "covered_branches")
    if any(not isinstance(totals.get(k), int) for k in required):
        return False, "Missing/non-integer coverage counts"
    st, covst = totals["num_statements"], totals["covered_lines"]
    br, covbr = totals["num_branches"], totals["covered_branches"]
    if st <= 0 or br <= 0:
        return False, "No statements/branches instrumented: inspect config and missing source"
    if covst > st or covbr > br:
        return False, "Invalid coverage counts"
    ok = (covst == st and covbr == br)
    return ok, f"Statement: {covst}/{st}; Branch: {covbr}/{br}"

if __name__ == "__main__":
    p=argparse.ArgumentParser()
    p.add_argument("coverage_json",type=Path)
    args=p.parse_args()
    success, message=evaluate(json.loads(args.coverage_json.read_text(encoding="utf-8")))
    print(message)
    raise SystemExit(0 if success else 1)
