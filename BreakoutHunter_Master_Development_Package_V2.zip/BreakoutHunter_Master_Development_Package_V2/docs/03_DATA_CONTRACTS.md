# Canonical Data Contracts v1 — implementasjonskrav

Maskinlesbare kontrakter finnes i `contracts/canonical_models.yaml` og `contracts/gpt_gateway.openapi.yaml`. **De er designspesifikasjoner, ikke implementerte Pydantic-klasser.** Byggeagenten genererer typede implementasjoner + verifiserer bakoverkompatibilitet.

## Globale invarianter
- Identifikatorer er stabile, ikke-navnegjettede: market, symbol, instrument_id, timeframe, strategy_version, data_version, schema_version.
- Tid i UTC med offset (`Z`) eller epoch ms eksplisitt. `observed_at` / `generated_at` / `available_as_of` holdes atskilt.
- Alle priser, volum, fees, funding og risiko over JSON wire-format er **decimal-strings**, med eksplisitt quote/base units; ingen float-beregning av ordrestørrelse.
- DTOer bruker `additionalProperties=false` der skjemavalidering tillater det; ukjente felt logges og avvises eller versjonshåndteres eksplisitt.
- Enumverdier i kontrakt. Resultater med manglende felt får `UNKNOWN`/`INCOMPLETE`, ikke implicit bullish.
- Gateway returnerer proveniens `evidence_id`, `data_quality`, `generated_at`, `strategy_version`, `schema_version`, `request_id`; AI konstruerer ikke markedsverdier selv.
- Paper- og shadow-order inneholder `mode=PAPER|SHADOW` og kan aldri sendes til ekte ordrefunksjon.

## Obligatoriske modeller
| Model | Eier | Viktigste felt/invarians |
|---|---|---|
| Instrument | market_data | instrument_id/market/contract_type/quote/lot_size/tick_size/status |
| MarketCandle | market_data | symbol/market/interval/start/end/OHLCV/is_closed/source/data_quality |
| MarketSnapshot | market_data | as-of data + spread/volume/ATR reference + source IDs |
| StructureEvent | market_structure | BOS/CHoCH/sweep, confirmed pivot timestamp, direction |
| FibonacciContext | indicators | anchored confirmed swings, zones/extensions/ATR normalization |
| RegimeState | regime | direction + volatility + confidence + UNKNOWN state |
| BreakoutCandidate | opportunity | WATCH/ARMED/CONFIRMED/RETEST/FAILED/EXPIRED + trigger + TTL |
| OpportunityAssessment | opportunity | readiness, quality, risk inputs, model evidence flags |
| EntryPlan | risk | direction, entry_zone, confirmation, invalidation, stop, TP, expiry |
| RiskDecision | risk | ALLOW/REDUCE/BLOCK/HALT, policy version, precise reasons |
| PaperOrder/Fill/Position | paper | causally ordered deterministic events; fees/funding/fill assumptions |
| ResearchExperiment | research | preregistration, data hash, split, seed, cost model, status |
| ValidationReport | validation | OOS, draws, n_eff, multiple tests, PASS/WAIT/FAIL |
| EvidenceRecord | knowledge | provenance, availability time, quality, immutable ID |
| StrategyDecisionPacket | governance | evidence-first, champion/challenger, recommendation, uncertainties |
| ApprovalRecord | governance | authorized user + exact version/hash, timestamp, policy/action |
| AiAnalysis | AI | local/API type + model version + context hash + uncertainty |
| ReleaseManifest/BackupManifest | ops | hashes/signatures/schema compatibility + recovery metadata |

## Kontraktforhandlingsregler
Ved endring av REQUIRED-felt, enum eller tidssemantikk: ny skjema-/protokollversjon; test gammel leser/ny skriver og ny leser/gammel skriver. Endring av `data_quality` eller strategidataversjon må invalidere signal-/AI-cache. Dev-agent B bygger mot fixtures mens Agent A implementerer produsent.

## Kritiske tester
Tidsstempler/UTC, decimal round-trip, spot/futures avgrensing, candle closed gate, deduplication, idempotent event IDs, paper v live, partial fill, entry > stop for long, short invers, negative cost input, evidence-as-of, stale data og schema drift.
