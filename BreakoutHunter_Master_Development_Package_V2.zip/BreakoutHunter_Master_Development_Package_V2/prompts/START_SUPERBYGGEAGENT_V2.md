# KLAR STARTPROMPT — lim inn i Superbyggeagenten

Du bygger **BreakoutHunter** fra denne utviklingspakken. Du har allerede to eksterne kodeagenter: bruk dem, men bygg IKKE en ny intern kodeagent-orkestrator.

## Autoritativ leserekkefølge (les kun nødvendige filer)
1. `README_START_HER.md`, `AGENTS.md`, `docs/00_DECISION_LOCK.md`, `docs/15_IMPLEMENTATION_DEFAULTS.md`.
2. `docs/16_ARCHITECTURE_FREEZE_AND_INTERFACES.md`, `docs/17_FAILURE_POLICY_AND_STATE_MACHINES.md`, `docs/23_CONTRACT_SEMANTICS.md`.
3. `tasks/TASK_BACKLOG_V2.json` + `tasks/README_V2_TASKS.md`, `plans/CRITICAL_PATH_AND_MILESTONES.md`.
4. `phases/PHASE_00.md` og KUN relevante `tasks/cards/BH-00-*.md`.

## Preflight før endring
- Kjør `python scripts/validate_registry.py`, `python scripts/validate_v2_package.py` og `python scripts/validate_contract_fixtures.py` i separat QA-miljø (installer jsonschema der det trengs). STOPP ved feil.
- Sjekk `git status`, eksisterende commit, branch policy og tilgjengelige verktøy/modeller. Ikke anta at GPT, BingX, NVIDIA eller internett er verifisert.
- Bruk **kun fase 00** til vi har fått brukeren sitt `y` for neste fase.

## To-agent-regler
- Velg to READY task cards med gyldige avhengigheter og ikke-overlappende `write_set`. Reserver branch/worktree og isolert runtime.
- Agentene leser kun kontrakten, egen task card, aktuelle kildefiler og tester. D0/lett modell eller deterministisk verktøy først når trygt; oppgrader ved målt behov. Ingen automatisk modellbytte dersom ikke støttet.
- Hver task må bevise positiv og negativ oracle, inkl. boundary/feiltilstand; ikke gjett resultater. Ingen ekte exchange orders, GPT Gateway read-only.
- Full QA før merge med statements=100 **og** branches=100 separat for egen kritisk kode, type/security/integration/misuse og ytelse der relevant. Bind testbevis til eksakt commit SHA og CI status. Feil på andre identiske forsøk utløser ny root cause, ikke nytt blindt forsøk.
- Risk-based cross review (obligatorisk for HIGH). Merge én om gangen til oppdatert HEAD. Oppdater prosjektstatus og kun relevante dokumenter.

## Stopp med følgende svar etter fase 00
TASK-ID | Agent | Endrede filer | commit SHA | statement% | branch% | sikkerhet | integrasjon | uløste funn | usage hvis eksponert. Foreslå fase 01, men **ikke start** uten `y`.

VIKTIG: Dokumentpakken er spesifikasjon. Ingen live trading, kode eller mål-PC-resultater er produsert bare fordi dokumentene finnes. `BH-REQ-091` er et åpent valg og må ikke merkes APPROVED.
