# PHASE 17: Physical Target-PC Installation & Final Release

**Mål:** Verify portable, protected, usable v1 end to end.

**Inngang:** Fase 16 godkjent med faktisk CI-evidence og GO.

**Relevant kildesteg:** BH-REQ-091

## Ferdigdefinerte kodeoppgaver (kan fordeles mellom 2 agenter)

### BH-17-01 — Build idempotent guided setup wizard
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Hardware/network/secrets optional, no silent UAC/format.

**Negativt akseptansekriterium:** Step 91 remains proposed default, require final choice.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/release/build_idempotent_guided_setup_wizard*`, `backend/tests/release/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-17-02 — Run clean install on separate target-PC profile
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** No VSCode/Git/Global Python required.

**Negativt akseptansekriterium:** Autostart and no admin normal runtime.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/release/run_clean_install_on_separate_target_pc_*`, `backend/tests/release/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-17-03 — Run end-to-end BingX-to-Telegram paper scenario
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Spot & futures, candidate -> risk -> paper -> outbox.

**Negativt akseptansekriterium:** Replayed signal not duplicate, no live order.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/release/run_end_to_end_bingx_to_telegram_paper_s*`, `backend/tests/release/*`.

**Avhengigheter:** BH-17-01.

### BH-17-04 — Audit ACL/firewall/gateway/network isolation
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D3_Critical

**Leveranse:** Actual Windows version hardware and permissions recorded.

**Negativt akseptansekriterium:** All unauthorized paths fail.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/release/audit_acl_firewall_gateway_network_isola*`, `backend/tests/release/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-17-05 — Run resource/soak benchmarks
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Scanner while normal PC apps open; AI unload/research pause.

**Negativt akseptansekriterium:** No uncontrolled resource spikes.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/release/run_resource_soak_benchmarks*`, `backend/tests/release/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-17-06 — Run backup restore and update rollback demonstration
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D3_Critical

**Leveranse:** Prove recoverable external copy and release pointer recovery.

**Negativt akseptansekriterium:** Corrupt backup/unsigned update fail closed.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/release/run_backup_restore_and_update_rollback_d*`, `backend/tests/release/*`.

**Avhengigheter:** BH-17-01.

### BH-17-07 — Produce final docs and approved baseline release
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Known-good SHA, suite evidence, open issues and GO checklist.

**Negativt akseptansekriterium:** No claim of verified production beyond evidence.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/release/produce_final_docs_and_approved_baseline*`, `backend/tests/release/*`.

**Avhengigheter:** BH-17-01, BH-17-02, BH-17-03, BH-17-04, BH-17-05, BH-17-06.

## Exit Gate
- Alle tasks PASS på eksakt merge commit.
- Statement og branch coverage kontrollert separat.
- Kritiske negative scenariotester, security scan og evt Windows mål-PC tester PASS.
- Release/testevidence og dokumentasjon oppdatert.
- Bruker GO før neste fase.
