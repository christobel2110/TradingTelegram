# PHASE 00: Governance & Quality Foundation

**Mål:** Lock scope, rules and CI before writing trading code.

**Inngang:** Godkjent Phase 00-scope og ren Git baseline.

**Relevant kildesteg:** BH-REQ-001, BH-REQ-002, BH-REQ-022, BH-REQ-023, BH-REQ-071, BH-REQ-072, BH-REQ-073, BH-REQ-074, BH-REQ-075, BH-REQ-076, BH-REQ-077, BH-REQ-078, BH-REQ-079, BH-REQ-080

## Ferdigdefinerte kodeoppgaver (kan fordeles mellom 2 agenter)

### BH-00-01 — Freeze requirements and decision log
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Registry maps 01–91 and unresolved step 91 explicitly.

**Negativt akseptansekriterium:** Missing/unapproved requirement cannot silently enter code.

**Skriveområde (foreslått lease):** `docs/; .github/workflows/; AGENTS.md; config/`, `tests/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-00-02 — Bootstrap independent repo layout
**Forslag eier:** agent_b · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** Python package + tests + docs + frontend shell and locked tooling decision.

**Negativt akseptansekriterium:** Fresh checkout resolves as documented.

**Skriveområde (foreslått lease):** `docs/; .github/workflows/; AGENTS.md; config/`, `tests/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-00-03 — Define AGENTS and two-agent file ownership
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Task contracts, two branch worktrees and collision procedure in docs.

**Negativt akseptansekriterium:** Both agents editing shared contract forbidden.

**Skriveområde (foreslått lease):** `docs/; .github/workflows/; AGENTS.md; config/`, `tests/*`.

**Avhengigheter:** BH-00-01.

### BH-00-04 — Configure versioned source provenance
**Forslag eier:** agent_b · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** Evidence table with checked URLs and explicit unverified items.

**Negativt akseptansekriterium:** No unsupported version or hardware claims.

**Skriveområde (foreslått lease):** `docs/; .github/workflows/; AGENTS.md; config/`, `tests/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-00-05 — Implement deterministic coverage gate
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D3_Critical

**Leveranse:** Test runner checks statements and branches separately by counts.

**Negativt akseptansekriterium:** Uncovered branch fails even if total appears 100%.

**Skriveområde (foreslått lease):** `docs/; .github/workflows/; AGENTS.md; config/`, `tests/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-00-06 — Configure protected CI and security checks
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D3_Critical

**Leveranse:** GitHub actions check code scan/type/tests/coverage and document ruleset setup.

**Negativt akseptansekriterium:** PR with failed required gate cannot merge when settings applied.

**Skriveområde (foreslått lease):** `docs/; .github/workflows/; AGENTS.md; config/`, `tests/*`.

**Avhengigheter:** BH-00-01.

### BH-00-07 — Phase 00 acceptance record
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Verify task evidence schema+commit SHA, signed review entries.

**Negativt akseptansekriterium:** Phase remains BLOCKED if CI proof missing.

**Skriveområde (foreslått lease):** `docs/; .github/workflows/; AGENTS.md; config/`, `tests/*`.

**Avhengigheter:** BH-00-01, BH-00-02, BH-00-03, BH-00-04, BH-00-05, BH-00-06.

## Exit Gate
- Alle tasks PASS på eksakt merge commit.
- Statement og branch coverage kontrollert separat.
- Kritiske negative scenariotester, security scan og evt Windows mål-PC tester PASS.
- Release/testevidence og dokumentasjon oppdatert.
- Bruker GO før neste fase.
