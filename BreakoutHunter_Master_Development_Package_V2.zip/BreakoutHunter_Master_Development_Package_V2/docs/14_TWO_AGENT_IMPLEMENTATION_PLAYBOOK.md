# Parallel Work Playbook — clear specs, zero new builder runtime

## Kort gjennomføring
1. Superbyggeagenten validerer dokumentenes schema, requirement IDs og faser.
2. Ved fasestart fryses kontraktversjon og `allowed_paths` i eksakte file-leases. A/B får hver sin task; reviewer ≠ implementer på HIGH.
3. Begge leser bare aktivt kontekstutdrag. A/B kan bygge mot frosne mocks/fixtures på delte grensesnitt.
4. Ferdig oppgave committes i egen worktree med testbevis. En integrasjon om gangen, eksakt ny merge-SHA testes.
5. Ved gjennomgående feil: stopp repetisjon, samle én root cause report, replan task; ikke utvid til nye agenttjenester.
6. Ved faseavslutning viser byggeagenten FULL QA-evidence og ber om `y` før fasebytte.

## Kritisk rekkefølge / åpne parallelle jobber
| Fase | Agent A første kandidat | Agent B første kandidat | Barrier |
|---|---|---|---|
| 00 | Registry + governance | Repo og kildegrunnlag | CI proof |
| 01 | Primitives + signal models | Market + risk models | Contract freeze |
| 02 | Windows ID/ACL policy | Installer skeleton / firewall | Sandbox verification |
| 03 | Market DB writer | Event journal/outbox | Crash replay |
| 04 | Futures/public adapters | Spot/WS adapters | Feed integration |
| 05 | Parquet archival | Polars query APIs | Point-in-time equivalence |
| 06 | Indicators/Fib | SMC and volumes | Golden no-lookahead fixtures |
| 07 | Candidate states/readiness | Quality/fusion | Replay acceptance |
| 08 | Entry/size/risk gates | Targets/portfolio risk | Negative risk tests |
| 09 | Paper event ledger | Shadow/Telegram | No-order demo |
| 10 | llama.cpp/lifecycle/cost gate | API/contexts/routing | LLM fault tests |
| 11 | Auth/schema GET Gateway | Network/tunnel & inbox | Abuse test |
| 12 | Experiment registry/search | Walk-forward/backtest | Research baseline |
| 13 | Statistical Evidence/Champion | User approval/Disagreement | Governance adversarial |
| 14 | Market memory/probabilities | Drift/calibration/ROI | Shadow-only validation |
| 15 | Local API/Admin | Frontend/mobile UX | Security + UI E2E |
| 16 | Providers & signed release | Restore/updater | Disaster drill |
| 17 | Clean install/E2E | Security/backup review | Final user GO |

Dette er forslag til oppgavestart. Større konflikter løses ved eksakte `file_lease_manifest`, ikke «agent A eier hele modulen» for alltid. Dokumentpakken er en implementasjonsbrief, ikke en faktisk Git repo-kontrollserver.
