# Portable Windows Deployment — Hardened Application Sandbox

## To forskjellige PC-er
Builder-PC: Superbyggeagent, Git, kompilering/test/CI. Mål-PC: vanlig Windows-bruk, 16GB system-RAM + RTX 8GB VRAM; ingen krav om VS Code/Codex/Python globalt. Bruk egen dedikert disk for `app/releases`, `runtime`, `models`, `config`, `data`, `logs`, `backups`, `updates`.

## Isolasjon uten falske løfter
Dedikert disk beskytter ikke OS; «Hardened Application Sandbox» er begrenset Windows service account/ACL, firewall, process control, hardening, signaturer og avgrenset kommunikasjon. Ikke påstå full VM/AppContainer-isolasjon uten målt test. Normal runtime ikke admin. Installasjon av service/firewall kan kreve UAC en gang. Windows og GPU-drivere forblir avhengigheter på systemdisken.

## Installer first-run
1. Verifiser signert manifest, kildesigner, diskidentitet/ledig plass; aldri automatisk formatér disk.
2. Detekter OS/CPU/RAM/GPU/VRAM/driver, sjekk modellruntime-kompatibilitet. Fail safe ved ukjent driver.
3. Pakk portable Python/runtime/binærfiler til dedikert disk; opprett ikke-admin identity/ACL via UAC-godkjent installer.
4. Opprett Market/Research DB og schema, backup-provider kontrakter og releasepointer.
5. Hent bare *approved* Qwen GGUF og llama.cpp CPU/CUDA build med hash + signatur/license. Test 2-4B class først, fallback mindre/CPU.
6. Kjør ressursbenchmark inkl. scanner interference; velg profil, lokalt API loopback.
7. Spør eksplisitt om Telegram token, OpenAI API-key og Gateway domenet/auth; hver integrasjon er VALGFRI og må kunne deaktiveres uten scannerstopp.
8. Installer Windows autostart ved innlogging/service etter policy; opprett firewall allowlist; krev aktiv tillatelse før offentlig tunnel.
9. Preflight end-to-end: public BingX read, local model, stale-data reject, journal write, read-only/no-orders, backup dry run og health.
10. Signer installasjonsrapport med faktisk komponentliste, tillatelser, ressursmålinger og mangler.

## Oppdateringer
Build på utviklings-PC -> signert artifact manifest/offline signing -> staging separat -> verify artifact and schema compatibility -> consistent DB backup -> user GO -> controlled code switch -> health -> rollback code if failure. Databasereversering kun dersom spesielt testet; ikke destruktiv restore automatisk. Modelloppgraderinger bruker separat manifest/QA/GO.

## Backup/recovery
Market DB SQLite Backup API, Research DB snapshot, Parquet file manifests. Hybrid providers local USB/NAS/cloud med offsite kryptering og separat recovery nøkkel. 3-2-1 designmål, men ikke påstå produksjonsklar før off-host backup + faktisk restore test. RPO/RTO mål kun mål, må måles på mål-PC.

## Discovery for GPT actions
Custom GPT med read-only Actions trenger internett-tilgjengelig HTTPS-endepunkt og schema/auth. Privat Tailscale-bare adresse er utilstrekkelig for server-side GPT Actions. Cloudflare Tunnel *kan* gjøre outbound tunnel, men offentlig endepunkt må sikres, begrenses og testes. Admin Control Center skal ikke eksponeres samme vei.
