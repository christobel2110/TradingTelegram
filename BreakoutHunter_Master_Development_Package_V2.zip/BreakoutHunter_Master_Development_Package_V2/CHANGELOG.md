# Changes

## V2 – 2026-10-19
- V1 beholdt som historisk grunnlag, men V2 er utførelsesplan.
- 141 oppgaver med eksplisitt file write_set, oppgavekort, positive/negative testorakler og revidert dependency DAG.
- Ni wire-kontrakter med JSON Schema draft 2020-12 og gyldige/ugyldige fixtures.
- Semantiske kontraktinvarianter, statemaskiner, failure policy, implementeringsdefaults og mål-PC/build-PC separasjon.
- V2 QA-skript og Model Usage Policy / modellrouting med no-AI som standard når beregning er deterministisk.
- Sikrere startprompt som bare tillater fase 00.
- Ingen funksjoner implementert; ingen runtime-, Windows- eller BingX-verifisering påstås.
