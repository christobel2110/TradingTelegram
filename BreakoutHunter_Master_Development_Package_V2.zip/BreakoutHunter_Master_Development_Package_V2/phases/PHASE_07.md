# PHASE 07: Breakout Opportunity Engine

**Mål:** Early and confirmed opportunities with deterministic ranking.

**Inngang:** Fase 06 godkjent med faktisk CI-evidence og GO.

**Relevant kildesteg:** BH-REQ-005, BH-REQ-007, BH-REQ-013, BH-REQ-065, BH-REQ-066

## Ferdigdefinerte kodeoppgaver (kan fordeles mellom 2 agenter)

### BH-07-01 — Implement candidate state machine
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** WATCH ARMED CONFIRMED RETEST FAILED EXPIRED INVALIDATED.

**Negativt akseptansekriterium:** No impossible state jumps/duplicates.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/opportunity/implement_candidate_state_machine*`, `backend/tests/opportunity/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-07-02 — Implement early regime and squeeze detector
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Compression, structural pressure and trigger proximity.

**Negativt akseptansekriterium:** Armed is not trade confirmation.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/opportunity/implement_early_regime_and_squeeze_detec*`, `backend/tests/opportunity/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-07-03 — Implement readiness score and ATR distance
**Forslag eier:** agent_a · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** Separate LONG/SHORT and near-level vs quality.

**Negativt akseptansekriterium:** Triggered price crossed not auto high readiness.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/opportunity/implement_readiness_score_and_atr_distan*`, `backend/tests/opportunity/*`.

**Avhengigheter:** BH-07-01.

### BH-07-04 — Implement breakout quality and score fusion
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Volume/SMC/momentum normalization without double-count.

**Negativt akseptansekriterium:** Correlated indicators do not triple-count.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/opportunity/implement_breakout_quality_and_score_fus*`, `backend/tests/opportunity/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-07-05 — Implement opportunity ranking and filters
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Spread, liquidity, regime, net RR eligibility.

**Negativt akseptansekriterium:** High score cannot bypass invalid data.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/opportunity/implement_opportunity_ranking_and_filter*`, `backend/tests/opportunity/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-07-06 — Implement adaptive weight research hooks
**Forslag eier:** agent_b · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** Baseline fixed weights with shadow versioned alterations.

**Negativt akseptansekriterium:** No dynamic production change before GO.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/opportunity/implement_adaptive_weight_research_hooks*`, `backend/tests/opportunity/*`.

**Avhengigheter:** BH-07-01.

### BH-07-07 — Implement candidate event & alert policy
**Forslag eier:** agent_a · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** Dedup/cooldown, expiry, status transitions.

**Negativt akseptansekriterium:** No flood when same candle is replayed.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/opportunity/implement_candidate_event_alert_policy*`, `backend/tests/opportunity/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-07-08 — Phase 07 historical replay acceptance
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Gold replay watch/armed/confirm/fail/expire.

**Negativt akseptansekriterium:** No falsely confirmed candle/pivot.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/opportunity/phase_07_historical_replay_acceptance*`, `backend/tests/opportunity/*`.

**Avhengigheter:** BH-07-01, BH-07-02, BH-07-03, BH-07-04, BH-07-05, BH-07-06, BH-07-07.

## Exit Gate
- Alle tasks PASS på eksakt merge commit.
- Statement og branch coverage kontrollert separat.
- Kritiske negative scenariotester, security scan og evt Windows mål-PC tester PASS.
- Release/testevidence og dokumentasjon oppdatert.
- Bruker GO før neste fase.
