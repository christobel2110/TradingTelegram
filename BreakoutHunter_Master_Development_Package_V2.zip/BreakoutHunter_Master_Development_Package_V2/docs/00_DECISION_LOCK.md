# Beslutningsregister — hva er låst?

| Område | Beslutning | Viktig presisering |
|---|---|---|
| Produkt | BingX Spot + Perpetual Futures, LONG/SHORT, tidlig og bekreftet breakout | V1 er analyse, varsler og paper; **aldri live ordre** |
| Utvikling | Superbyggeagent har allerede 2 byggeagenter på utviklings-PC | Ikke bygg tilsvarende runtime inne i BreakoutHunter |
| Runtime | Windows på annen PC, 16GB RAM og 8GB NVIDIA VRAM | CPU/modell/driver/diskstørrelse ukjent |
| Installasjon | Egen harddisk, herdet programruntime | Ikke sterk VM-isolasjon, OS trenger systemdisk |
| Data | Market SQLite + Research SQLite + Parquet | Ikke cross-DB atomisitet; idempotent sync |
| LLM | Portable llama.cpp/GGUF, lokal Qwen som kandidat | Konkret modell/kvantisering bestemmes ved benchmark |
| API | OpenAI API selektivt, budsjettgated | Modelltilgang/priser verifiseres ved integrasjon |
| ChatGPT | Egendefinert GPT med read-only Actions | GPT er interaktiv, ikke kontinuerlig scanner |
| Strategi | Adaptive Scoring, Research Lab, vitenskapelig validering | Adaptive endringer først SHADOW, manuell GO til produksjon |
| Drift | Supervised recovery, observability, backup, signed updates | Destruktiv restore og aktivering krever GO |
| Tilgang | Command Center, Telegram, privat mobil VPN | GPT Actions krever separat tilgjengelig HTTPS, ikke lokal VPN alene |
| Uavklart | Steg 91 guided zero-touch installer | Foreslått; onboarding med eksplisitt nøkkel-/rettighetsgodkjenning er safe default |

## Ikke-implementerte/ikke-verifiserte forhold
- Faktisk API-endepunkt/rate limits for alle ønskede BingX-data må sjekkes mot offisiell Spot/Futures-dokumentasjon ved implementasjon.
- Autostart og nettverksisolasjon avhenger av Windows edition og administrative rettigheter.
- GPT Actions tilkobling krever domenenavn, autentisering, TLS, testing; ingen forhåndsbekreftet domeneleveranse.
- Foretrukne modeller er kun startkandidater til evals, ikke en fast modellgaranti.
