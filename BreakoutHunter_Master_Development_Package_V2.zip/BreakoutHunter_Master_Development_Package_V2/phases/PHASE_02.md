# PHASE 02: Portable Sandbox & Runtime Foundation

**Mål:** Protect target PC and isolate critical scanner.

**Inngang:** Fase 01 godkjent med faktisk CI-evidence og GO.

**Relevant kildesteg:** BH-REQ-003, BH-REQ-004, BH-REQ-024, BH-REQ-025, BH-REQ-026, BH-REQ-027, BH-REQ-082, BH-REQ-083

## Ferdigdefinerte kodeoppgaver (kan fordeles mellom 2 agenter)

### BH-02-01 — Specify target hardware and OS preflight
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Verify 16GB/8GB profile; detect actual CPU/GPU/driver/disk.

**Negativt akseptansekriterium:** Unknown capability triggers safe mode.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/runtime/specify_target_hardware_and_os_preflight*`, `backend/tests/runtime/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-02-02 — Create dedicated-disk layout and installer skeleton
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Relative paths, no global python, no drive formatting.

**Negativt akseptansekriterium:** Install on non-C disk with no assumed drive letter.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/runtime/create_dedicated_disk_layout_and_install*`, `backend/tests/runtime/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-02-03 — Implement least-privilege runtime identity and ACL tests
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** No-admin service account and limited filesystem access.

**Negativt akseptansekriterium:** Cannot read arbitrary Windows user files.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/runtime/implement_least_privilege_runtime_identi*`, `backend/tests/runtime/*`.

**Avhengigheter:** BH-02-01.

### BH-02-04 — Implement firewall and network policy
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Allowed public market and selected API egress, local model loopback.

**Negativt akseptansekriterium:** Unauthorized network route denied.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/runtime/implement_firewall_and_network_policy*`, `backend/tests/runtime/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-02-05 — Implement supervisor lifecycle and circuit breakers
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Health/backoff/restart budget/quarantine.

**Negativt akseptansekriterium:** Three failures do not loop indefinitely.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/runtime/implement_supervisor_lifecycle_and_circu*`, `backend/tests/runtime/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-02-06 — Implement event/metric logging foundation
**Forslag eier:** agent_b · **Risiko:** MEDIUM · **Modell:** D1_Standard

**Leveranse:** JSONL rotating health traces and secrets redaction.

**Negativt akseptansekriterium:** Redact all credentials and avoid blocking scanner.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/runtime/implement_event_metric_logging_foundatio*`, `backend/tests/runtime/*`.

**Avhengigheter:** BH-02-01.

### BH-02-07 — Implement resource guard foundation
**Forslag eier:** agent_a · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** CPU RAM VRAM measurement, caps and staged degradation.

**Negativt akseptansekriterium:** Research/LLM stop before scanner degrades.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/runtime/implement_resource_guard_foundation*`, `backend/tests/runtime/*`.

**Avhengigheter:** Ingen ekstra task-deps; fasegate og kontrakter gjelder.

### BH-02-08 — Phase 02 sandbox acceptance
**Forslag eier:** agent_b · **Risiko:** HIGH · **Modell:** D2_Complex

**Leveranse:** Fault test permissions/startup/stop and restricted egress.

**Negativt akseptansekriterium:** Lack of admin isolation fails deployment.

**Skriveområde (foreslått lease):** `backend/src/breakouthunter/runtime/phase_02_sandbox_acceptance*`, `backend/tests/runtime/*`.

**Avhengigheter:** BH-02-01, BH-02-02, BH-02-03, BH-02-04, BH-02-05, BH-02-06, BH-02-07.

## Exit Gate
- Alle tasks PASS på eksakt merge commit.
- Statement og branch coverage kontrollert separat.
- Kritiske negative scenariotester, security scan og evt Windows mål-PC tester PASS.
- Release/testevidence og dokumentasjon oppdatert.
- Bruker GO før neste fase.
