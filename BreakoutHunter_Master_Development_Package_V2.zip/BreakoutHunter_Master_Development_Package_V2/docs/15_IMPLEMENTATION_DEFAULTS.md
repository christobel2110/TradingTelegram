# Implementation Defaults — avgjørelser som reduserer avklaringer

**Gjeldende for kodearbeid, ikke ny brukerbeslutning:** Designvalg under skal brukes som standard med mindre de kolliderer med vedtatt krav, faktisk verifisert API eller sikkerhet. Avvik krever ADR og teknisk dokumentasjon; sikkerhetsendringer krever brukerens GO.

| Tema | Eksakt standard | STOP/eskalering ved |
|---|---|---|
| Språk/backend | Python 3.12+, `src/` layout, `pytest`, `ruff`, `pyright` (låses i repo) | runtime/build-inkompatibilitet |
| Frontend | React+TypeScript, bygget statisk; FastAPI serverer assets | autorisasjon/credential svakhet |
| Pris/volum/risiko | `Decimal` i kalkulator, kanoniske desimalstrenger i JSON, tick/step rounding `ROUND_DOWN` der størrelsesgrense, aldri float i marginbeslutning | rounding kan overskride risk cap |
| Tid | UTC RFC3339 Z i API, UTC epoch millis internt, candle interval half-open `[open, close)` | ukjent klokkekilde/datasemantikk |
| Candle | `is_closed=true` først ved verifisert lukket candle; uferdig oppdateres ikke som endelig | datagap/fordreid sekvens |
| Signal-ID | stabil UUIDv5 eller SHA-256 av `(market,instrument,timeframe,setup_id,status,trigger_close_at,strategy_version)` | manglende stabile nøkkelverdier |
| Event journal | én Market DB SQLite WAL writer; atomisk journal + outbox; `UNIQUE(event_id)`; åpen fil/restart via replay | databasefeil eller data tap |
| Delivery | at-least-once + idempotent consumer, `sent` etter provider acknowledgement; ikke lov å love exactly-once ekstern leveranse | ukjent provider receipt |
| Research synk | persistert watermark og idempotente overføringer fra Market DB til Research DB; ingen to-DB commit-garanti | hull eller ulike source hashes |
| Historikk | nylige candles SQLite, eldre Parquet etter verified manifest og atomisk publish; arkivering må aldri slette kilde før verifikasjon | checksum eller tidsrekke brudd |
| SMC | pivot kun etter `right_bars` lukkede barer; events immutable; påbegynte pivoter kun PROVISIONAL | ikke-repaint property brutt |
| Brudd | WATCH/ARMED/CONFIRMED/RETEST/FAILED/EXPIRED state machine; `CONFIRMED` krever close+volum+datakvalitet, score alene aldri nok | undefined state transition |
| Paper | PAPER/SHADOW isolerte ledger, aldri Exchange Order Adapter; fills basert på tillatte data, konservativ/usikker fill ved manglende ordrebok | ukjent feed/kontrakt |
| Risiko | hard caps i deterministisk Python; `BLOCK` på unknown critical facts; `HALT` ved systemkorrupt tilstand | regulatoriske/ordrespesifikk ukjent |
| LLM | portable llama.cpp (GGUF), prioriter godkjent 2–4B-Q4 kandidat, ingen garantert modelltilgang; lokal inferens aldri i scanner hot path | målt VRAM/latency over grense |
| OpenAI API | disabled in fresh install til bruker legger inn key og budsjett; ulike runtime research/live budsjetter | pris/modellkvote ikke verifisert |
| Custom GPT | GET-only, auth/rate-limit, as-of, read-only evidence; eksponering i offentlig HTTPS først etter eksplisitt GO | uverifisert domene/tilgang |
| Sandboxing | herdet Windows service identity + ACL + firewall + begrensede prosesser; **ikke VM-ekvivalent isolasjon** | sikkerhetskrav krever OS isolasjon |
| Backup/oppdatering | konsistent SQLite backup, separat medium, signerte releases, fail-closed, rollback med skjema-kompatibilitet | destructive change uten recovery |

## Prioritet mellom krav
1. Finansiell og systemisk sikkerhet / ingen ekte ordre; 2. dataintegritet og provenance; 3. eksplisitte brukerbeslutninger; 4. testbarhet; 5. lokal brukeropplevelse; 6. ressurser og usage. Ytelsesgevinst kan ikke begrunne brudd på 1–4.

## Ingen stopp for trivielle implementasjonsvalg
Velg minimal sikker løsning som følger kontrakten; dokumenter ADR når endringen påvirker offentlige grensesnitt, schema, risikologikk eller trust boundaries. Bruk `BLOCKED` bare ved uavklart sikkerhet, motstridende krav eller nødvendig ekstern autorisasjon. For valg som krever reelle PC-/API-data, skriv preflight-sjekk og et fail-closed fallback i stedet for gjetning.
