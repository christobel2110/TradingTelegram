# Phase ## Completion Report — TEMPLATE

- Phase / objective:
- Released/merged commit SHA:
- Task IDs & commits:
- Changed source/contract/docs:
- Unit/integration/fault/security/performance tests with artifact URI/hash:
- Statement covered / total:
- Branches covered / total:
- Skips/exclusions (must be justified):
- Hardware: builder / target / versions:
- Measured latency CPU RAM VRAM + baseline:
- Open risks/blocked requirements:
- Reviewer(s) and approval evidence:
- User decision needed: `y` before next phase:
