# Architecture Freeze — konkrete prosess- og dataeierskap

## Runtime boundary (mål-PC)
- **Scanner Core / least-privilege process:** les BingX public markets, valider, journalfør og produser signaler/risiko. Ingen avhengighet til AI/Research/GPT for korrekt drift. Scanner eier den logiske Market DB skrivekøen.
- **AI Worker:** henter *immutable Evidence Package* fra read model, kjører portable llama.cpp eller betalt API gjennom budget gate, skriver analyser via kontrollert append-only outbox. Ingen rett til signalstatus/risk override.
- **Research Worker:** leser arkiver/replica, skriver bare `research.db`-data. Ingen DB-skriving til Market DB og ingen nett-/BingX-trade-adapter.
- **Interface Worker:** Dashboard/Telegram og separat GET-only GPT Gateway. Administrativ Command Center må ha egen auth og må **ikke** eksponeres i offentlig GPT-tunnel.
- **Supervisor/installer:** separate minimal privilegier, health og restart-budget; administrative endringer kun gjennom elevation ved eksplisitt bruker-GO.

## Eneste autoritative kontrakter
`contracts/jsonschema/*.schema.json` definerer wire v2 for kritiske DTOer. Eldre `contracts/canonical_models.yaml` bevares som *funksjonell katalog*, men ved konflikt: v2 schema + denne filens invariants eier valideringsformatet. Ikke generer Python fra upresis pseudo-typebeskrivelse uten schema-test.

## Interface matrix (sender -> mottaker)
| Producer | Consumer | Kontrakt | Data/feilpolicy |
|---|---|---|---|
| BingX adapters | Market normalizer | `Instrument`, `MarketCandle` | spot/futures separate; unknown field→INVALID |
| Normalizer | Market journal | `MarketCandle`, `MarketEvent` | write-once event ID; gap→BLOCK affected symbol |
| Market journal | Scanner | immutable candle sequence | no wait for LLM; replay idempotent |
| Scanner | Risk Gate | `BreakoutCandidate`, `EntryPlan` | no stale/unfinished candle; invalid→BLOCK |
| Risk Gate | Outbox | `RiskDecision`, `EvidenceEnvelope` | only deterministic evidence, versioned hash |
| Outbox | Telegram | notification envelope/idempotency key | bounded retries; after ack mark sent; duplicates possible externally |
| Evidence read model | AI Worker | `EvidenceEnvelope` | max size/TTL/context, no mutable candle reference |
| Market snapshot sync | Research worker | event batches + watermark | at-least-once + `UNIQUE` IDs, checkpoint last committed |
| Research validator | Strategy Inbox | `ValidationReport`, `StrategyDecisionPacket` | conclusions tied to frozen artifacts |
| Command Center | Governance | authenticated approval | exact report hash + actor; GPT forbidden to write |
| GPT Gateway | ChatGPT GPT | GET-only OpenAPI | auth, throttling, stale flags, no OS/process read |

## Contract compatibility
- `schema_version` semver MAJOR.MINOR; incompatible enum/field-semantic change increments MAJOR.
- Producer never silently drops required info. Clients reject unknown MAJOR and can tolerate additive MINOR only where schema declares explicit extension point (critical DTOs: no arbitrary fields).
- Prices as decimal strings; binary float not for risk/positions. `observed_at`, `ingested_at`, `available_as_of`, `generated_at` distinct. Store UTC and `source` for each critical observation.
- Every phase must include one positive and one negative contract test for each DTO modified.

## Data security invariant
No credential or approval enters Market Evidence Package. Offline/nokkel-løs install supports public BingX read-only; no private account endpoint or exchange order route included in v1. Network must have explicit allowlist and schema/protocol validation, not merely a convention.
