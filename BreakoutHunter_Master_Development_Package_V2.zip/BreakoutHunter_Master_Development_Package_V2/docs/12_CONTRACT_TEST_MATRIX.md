# Contract-test-matrise

| ID | Invariant | Expected |
|---|---|---|
| CT-001 | negative/zero price or tick_size | REJECT |
| CT-002 | future pivot referenced before confirm | REJECT/no signal |
| CT-003 | `is_closed=false` and CONFIRMED | REJECT |
| CT-004 | Spot SHORT requested | REJECT for v1 |
| CT-005 | LONG stop ≥ entry low / SHORT stop ≤ entry high | REJECT |
| CT-006 | Market DB duplicate event ID after replay | one persisted signal |
| CT-007 | stale market as-of | no live opportunity claim |
| CT-008 | research record from later timestamp in historic backtest | REJECT leakage |
| CT-009 | RiskDecision missing margin data | BLOCK |
| CT-010 | Paper fill before order or overfill qty | REJECT |
| CT-011 | GPT Gateway POST approve/trade | 405/404; no write route |
| CT-012 | `ApprovalRecord` hash mismatches release | REJECT |
| CT-013 | backup hash/signature mismatch | FAIL restore |
| CT-014 | release signature invalid | REJECT activation |
| CT-015 | unsupported OpenAI model ID | routing disabled/fallback |
| CT-016 | complete candle after restart reconciled | historical backfill only, not simulated forward fill |
| CT-017 | duplicate price event, different market | separate independent rows |
| CT-018 | UTC transition and daylight saving | no timezone-dependent rollover |
| CT-019 | required schema field missing | schema error with code |
| CT-020 | money decimal round-trip 0.00000001 | exact preservation |

Implementer frosne fixtures og test mot både serializer/deserializer og databaseadapterne. Ved endring i kontraktversjon må consumer driven tests oppdateres av egen godkjent kontraktoppgave.
