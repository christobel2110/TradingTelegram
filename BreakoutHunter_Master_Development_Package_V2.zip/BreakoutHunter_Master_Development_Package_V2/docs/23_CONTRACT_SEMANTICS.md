# Semantic constraints utenfor JSON Schema

`contracts/jsonschema/*.schema.json` validerer wire-format, felt, enum og negative DTO-eksempler. Korrekt økonomi, tid og markedssemantikk **kan ikke** bestemmes med JSON Schema alene. Superbyggeagenten MÅ implementere underliggende semantiske validatorer før integrasjon.

| Kontrakt | Positiv invariant | Obligatorisk negativ test |
|---|---|---|
| Instrument | tick_size>0, step_size>0, status fra godkjent spot/futures-univers | ikke handelsbart/par med ugyldig tick |
| MarketCandle | `open_at < close_at`; high>=max(open,close,low); low<=min(open,close,high); known frame length; `available_as_of >= close_at` for lukkede barer | OHLC-inversjon, feil 15m-grense, duplikat, fremtidig bar, datagap |
| BreakoutCandidate | WATCH/ARMED kan ikke oppgraderes til CONFIRMED kun pga score; krever verifisert lukket candle, trigger og kvalitet VALID | open candle, utløpt oppsett, feil marked/retning |
| EntryPlan | LONG: stop<entry_low<=entry_high<targets i stigende rekkefølge; SHORT speilvendt; sum target-fractions <=1; Decimal/tick-alignment | stop på feil side, TP-order, fraction>1, tick-avvik |
| RiskDecision | `BLOCK/HALT` krever allowed_notional_quote=0; `ALLOW/REDUCE` krever VALID data og positiv tillatt størrelse | stale data gir ALLOW, null risiko og positiv notional, live execution |
| PaperOrder | Paper/shadow-only ledger; limit/stop/market med differensiert fill-policy; order-lifecycle validert | faktisk order endpoint forsøkt, fill før ordre, duplicate fill |
| EvidenceEnvelope | observasjon <= genereringstid; kjente datakilder; sensitive felt filtrert | future timestamp, skjult api_secret, full lokal filbane |
| ResearchExperiment | preregistered_at før test, train end < test start (med purge/embargo etter label horizon), datasett SHA låst | data leak, rebruk av urørt test under tuning |
| ApprovalRecord | fysisk autentisert bruker i Command Center; artifact sha256 matcher eksakt immutable versjon; GPT read-only | GPT Action forsøker signere/godkjenne, mismatched hash |

**Oracle-prinsipp:** Hver validator skal ha uavhengig referansecase, property-based test der egnet, boundary- og restart/integration-test. 100 % coverage uten negative oracle er ikke PASS.
