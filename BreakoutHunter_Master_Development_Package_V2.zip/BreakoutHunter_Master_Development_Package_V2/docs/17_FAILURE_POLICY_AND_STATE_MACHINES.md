# Failure Policy, State Machines & Timelines

## Critical fail-closed decisions
| Condition | Detection | Behaviour | Recovery |
|---|---|---|---|
| Incomplete candle / timestamp gap | continuity checks, `is_closed=false` | no CONFIRMED, mark affected instrument INCOMPLETE | backfill + revalidate |
| Time drift (Windows clock) | compare exchange event as-of vs monotonic ingest | block affected timestamp-dependent decisions | fix time; recorded outcome |
| WebSocket disconnected | missing heartbeat / transport exception | mark stale, no fresh analysis; preserve journal | bounded reconnect, REST reconcile |
| Duplicate journal event | uniqueness key | no second signal state change | idempotent ack |
| WAL/disk full | failed durable transaction | `HALT` affected new signals; keep audit if possible | operator triage + verified restore |
| Telegram timeout | outbox lacks ack | retry bounded, key unchanged, never claim guaranteed exactly-once | reconcile provider receipt if possible |
| Qwen OOM | watchdog + allocation gate | unload, cooldown, rule-based scanner continues | smaller model / API budget gate |
| OpenAI API over cost cap | atomic token-cost reservation fails | no paid call, retain no-AI evidence | user changes budget |
| Research worker crashes | job heartbeat missing | abort checkpointed task, scanner unaffected | isolated recovery |
| Critical risk input null | DTO or invariants fail | BLOCK; never fill missing figures | fetch verified data |
| GPT Gateway unauthenticated | invalid/missing bearer | 401; no data, no admin route | authorized token |
| Update manifest tampered | sig/hash check fails | reject staged release | trusted release only |
| Backup no usable key | decrypt integrity fails | preserve original, no destructive restore | recover key or escalate |

## Candidate lifecycle (allowed transitions)
`NEW -> WATCH -> ARMED -> CONFIRMED -> RETEST -> CLOSED`; `WATCH|ARMED|CONFIRMED|RETEST -> FAILED|EXPIRED` when explicit invalidation/TTL; `CONFIRMED -> CLOSED` if strategy signal canceled by policy. `UNKNOWN` data quality halts transitions. **No automatic promotion based on scores**.

Define separate `signal_status` vs `paper_order_status` vs `strategy_validation_status`; never reuse `PASS` from research to mean execution confirmation. Strategy promotion requires `validation=PASS`, `shadow=PASS`, `approval=AUTHORIZED`, and `released_artifact.sha256` exact match.

## Model lifecycle
`UNLOADED -> LOADING -> READY -> BUSY -> READY -> UNLOADING -> UNLOADED`; any active state may go `ERROR -> COOLDOWN -> UNLOADED`. Max 1 local inference; crash never blocks scanner hot path.

## Recovery event causality
`market_event_id` timestamp/version → calculation→ `signal_id` → `risk_decision_id` → outbox id. Journal and outbox row created in one Market DB transaction; sender ack is separate. Recover writer from newest durable cursor. Replayed event must not duplicate signal/outbox rows.

## Hard stop categories
1. **Immediate safety HALT** without approval: suspected data tampering, unknown margin, invalid schema, critical disk/database failure.
2. **Non-destructive self-heal** without approval: reconnect, clean cache, restart worker, bounded retry.
3. **Human approved**: release activation, strategy promotion, new egress, destructive restore, changed risk policy.

## Test proofs per failure
Every failure case carries a fixture or reproducible injection script, expected state transition, alert, durable record and return-to-healthy evidence. No PASS solely from happy-path tests.
