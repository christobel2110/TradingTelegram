# BREAKOUTHUNTER — MASTER DEVELOPMENT PACKAGE V2

**Dokumentstatus:** designspecifikasjon, ikke implementert/tradeklar programvare. Utvikles på annen PC enn mål-PC. Mål-PC kjører Windows, 16 GB RAM, NVIDIA RTX 8 GB VRAM og egen disk; faktisk CPU, drivere, diskplass og Windows-edition må kontrolleres i preflight.

## Hva V2 løser
V1 ga godt overordnet omfang, men generiske task-kriterier og tekstlige datakontrakter tvang kodeagentene til å ta for mange egne designbeslutninger. V2 supplerer med **konkrete task cards**, eksplisitt filansvar, reell cross-phase dependency DAG, maskinvaliderbare kontrakter, positive/negative golden-fixtures, førstegangsintegrasjon, feilmatrise og prioriterte milepæler.

## Les nøyaktig i denne rekkefølgen
1. `AGENTS.md` → `docs/00_DECISION_LOCK.md` → `docs/15_IMPLEMENTATION_DEFAULTS.md`.
2. `docs/16_ARCHITECTURE_FREEZE_AND_INTERFACES.md` → `docs/17_FAILURE_POLICY_AND_STATE_MACHINES.md`.
3. `contracts/jsonschema/` og `contracts/fixtures/` → `docs/18_GOLDEN_FIXTURES_AND_ORACLES.md`.
4. `plans/CRITICAL_PATH_AND_MILESTONES.md`, `tasks/TASK_BACKLOG_V2.json`; les **bare** aktiv `tasks/cards/BH-XX-YY.md` + nødvendig kontrakt.
5. `docs/19_EFFICIENT_MODEL_ROUTING.md`, `docs/20_RELEASE_VALIDATION_MATRIX.md`, `prompts/START_SUPERBYGGEAGENT_V2.md`.

## Arbeidsregler
- Superbyggeagenten har allerede **to eksterne kodeagenter**. **IKKE implementer enda et orkestratorsystem** i BreakoutHunter.
- Kjør kun godkjent fase. Innen fasen kan to tasks kjøres parallelt når `depends_on`, `write_set` og security gates tillater det. Stopp før neste fase og be om `y`.
- Kritisk kilde til sannhet: sikkerhetskrav → godkjent beslutningsregister → JSON Schema v2 / kontrakter → phase acceptance → task cards. Eksempler er aldri en autoritet som kan overstyre sikkerhet.
- **Aldri live ordreutførelse** i første leveranse. BingX for markedsdata, OpenAI API via budsjett, GPT Actions bare read-only.
- `BH-REQ-091` er fortsatt **PROPOSED_NOT_APPROVED**; det finnes en sikker, styrt installasjonsplan som default, uten å late som brukeren godkjente alternativet.

## Slik kvalitetssikres dokumentpakken lokalt
`python scripts/validate_registry.py` (V1 kompatibilitet), `python scripts/validate_v2_package.py`; ved `jsonschema` installert: `python scripts/validate_contract_fixtures.py`.

## Hva pakken IKKE beviser
Den verifiserer dokumentstruktur, oppgave-DAG og eksempelkontrakter. Den beviser ikke at BingX-endepunkter, GPU, GPT Actions, CI-regler, Windows ACL eller restore virker på mål-PC. Disse må testes på riktig miljø og dokumenteres på en konkret commit.

## Filansvar og V1-kompatibilitet
`phases/PHASE_XX.md` og `tasks/TASK_BACKLOG.json` inneholder V1-bakgrunn. For faktisk dispatch styrer `tasks/TASK_BACKLOG_V2.json` og `tasks/cards/` eksakt omfang, `write_set`, positive/negative orakler og avhengigheter. Superbyggeagenten oppdaterer globale prosjektstatusfiler etter integrasjon; byggeagentene skriver bare filer i sin task-allowlist.
