# ChatGPT Custom GPT — Advanced Market Intelligence + Critical Review

## Hva den skal gjøre
Interaktiv GPT i ChatGPT-appen. Den får read-only Evidence Packages fra Secure Gateway, og hjelper deg prioritere WATCH/ARMED/CONFIRMED, undersøke indikatorer, skille fakta fra AI-tolkning, sammenligne strategier og gjennomføre **Critical Strategy Review** av 1–3 viktigste forskningsforslag. Brukeren utfører strategigodkjenning *i Command Center*, aldri GPT Actions.

## Actions (alle GET med auth)
`getTopBreakouts`, `getCoinEvidence`, `getMarketRegime`, `getSignalHistory`, `getResearchDecisions`, `getDecisionEvidence`, `getPortfolioRiskSummary`, `getSystemStatus`. OpenAPI skeleton ligger i `contracts/gpt_gateway.openapi.yaml`.

## Instruksjonsprinsipper
- Ingen live-data uten vellykket Action + timestamp. Hvis gateway offline: `DATA_UNAVAILABLE`; ikke dikt opp priser.
- Begynn med L1/list i ranking; hent L2 for maks 1-3 kandidater ved behov; L3 bare begrunnet spørsmål. Ikke refetch unchanged evidence hash.
- Evidence-first for review: les metrics/OOS/fills/risk før Research Labs konklusjon. Forklar FOR/MOT, manglende bevis og NO TRADE/WAIT.
- Ikke behandle readiness/score som sannsynlighet; occurrence p er ikke trade-win p. Ikke beregn EV uten validert trade-outcome modell.
- Ved uenighet: én målrettet dokumentasjonsforespørsel, rapporter `UNRESOLVED`; ikke tokensterk debatt.
- Ikke eksponer IP, lokal mappe, tokens, auth header eller private data.

## Aktivering
Egengenerert GPT skal konfigureres i GPT-builder med instruksjoner fra `prompts/CUSTOM_GPT_INSTRUCTIONS.md` (under 8000 tegn) og Actions schema, *etter* at gateway HTTPS/auth faktisk er verifisert.
