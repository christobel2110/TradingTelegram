# Faseoversikt og risikobelastning

| Fase | Oppgaver | Kritiske/HIGH oppgaver | Akseptansetest |
|---:|---:|---:|---|
| 00 | 7 | 5 | BH-00-07 |
| 01 | 8 | 8 | BH-01-08 |
| 02 | 8 | 7 | BH-02-08 |
| 03 | 7 | 6 | BH-03-07 |
| 04 | 8 | 7 | BH-04-08 |
| 05 | 7 | 5 | BH-05-07 |
| 06 | 8 | 6 | BH-06-08 |
| 07 | 8 | 5 | BH-07-08 |
| 08 | 8 | 7 | BH-08-08 |
| 09 | 8 | 7 | BH-09-08 |
| 10 | 9 | 7 | BH-10-09 |
| 11 | 7 | 5 | BH-11-07 |
| 12 | 8 | 5 | BH-12-08 |
| 13 | 8 | 6 | BH-13-08 |
| 14 | 9 | 5 | BH-14-09 |
| 15 | 7 | 4 | BH-15-07 |
| 16 | 9 | 8 | BH-16-09 |
| 17 | 7 | 7 | BH-17-07 |

**Dokumentasjon ≠ verifisert implementering.** Alle oppgaver er NOT_STARTED til Superbyggeagenten har faktisk kode og CI-evidens.
