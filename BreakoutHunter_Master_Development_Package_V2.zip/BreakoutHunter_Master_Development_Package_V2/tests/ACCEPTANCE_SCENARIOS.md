# Testkatalog — end-to-end og feilinjeksjon

| Scenario ID | Test | Må oppfylles |
|---|---|---|
| E2E-001 | 100 instrument Spot+Futures public ingest and seed candles | stabil data quality og instrument identifiers |
| E2E-002 | 5m confirmed close after WATCH/ARMED | registrer ett CONFIRMED med evidens |
| E2E-003 | WATCH expired / false breakout | FAILED/EXPIRED og historikk, ikke trade |
| E2E-004 | RSI/Fib/SMC indicator + MTF golden fixtures | as-of/filled candles korrekt |
| E2E-005 | illiquid futures LONG 20x risk proposal | BLOCK når margin/slippage safety feiler |
| E2E-006 | two correlated LONGs in different strategies | aggreger cluster risk; separate SHADOW alternatives |
| E2E-007 | paper limit without orderbook data | no guaranteed fill; conservative assumption |
| E2E-008 | crash between market journal and telegram send | signal preserved, dedup output |
| E2E-009 | Research DB unavailable | scanner continues, research paused |
| E2E-010 | 16GB RAM / 8GB RTX during VS Code + Browser | local LLM unloads and research pauses when pressure |
| E2E-011 | no Qwen/no OpenAI funds | Python produces rule-based analysis and alert |
| E2E-012 | custom GPT Actions GET authorized | only L1-L3 read-only, auth and data timestamp |
| E2E-013 | POST `/approve` `/orders` path | not implemented, reject, audit |
| E2E-014 | probability model occurrence vs trade success | never conflate or compute fake net EV |
| E2E-015 | model drift on bad data | invalid data quarantined, not optimizing wrong source |
| E2E-016 | shadow challenger not validated | cannot promote despite better backtest PF |
| E2E-017 | signed app/model upgrade invalid signature | reject before code execution |
| E2E-018 | backup of Market+Research+Parquet to external | restore to empty disk and verify schema/hash |
| E2E-019 | Windows installer target disk differs from builder | starts without Python/VS Code/Git global |
| E2E-020 | disk lost/offline | no false online claim, report offline/stale |
| E2E-021 | code roll back with irreversible DB migration | fail safe, no destructive silent restore |
| E2E-022 | two builder agents modify shared file concurrently | ownership conflict blocked before integration |
| E2E-023 | API budget used by two requests same moment | atomic reservation prevents overrun |
| E2E-024 | GPT summary removes stop-loss precision | compression validation rejects altered packet |
| E2E-025 | historical pivot/look-ahead leak | rejects non-as-of feature |

Her er bare spesifikasjoner for testimplementasjon, **ingen rapporterte passerte tester**.
