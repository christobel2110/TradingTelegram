# Operations Runbook — logging, feil, backup, rollbacks

## SLO startmål (må benchmarkes, ingen garantier)
100 likvide instrumenter × 4 TF; 95p closed candle detection <2s under normal test workload; critical market data missing <1 min detect; no duplicate idempotent signal IDs; scanner RAM mål <500MB; resource-aware worker pause ved press. Fastsett realistiske verdier etter mål-PC måling.

## Driftsmodi
HEALTHY: market feed/data integrity & journal OK; DEGRADED: AI/research/dashboard utilgjengelig; UNHEALTHY: market data stale, journal locked, risk engine unverified -> stop affected signals; QUARANTINE etter gjentatte recoveryfeil. Supervisor kan ikke redigere kode/strategier.

## Fail matrix
| Feil | Trygg respons | Utestengt adferd |
|---|---|---|
| WS disconnect | reconnect backoff + REST gap reconciliation | behandle gamle candles som live |
| API rate limit | obey retry-after / pause discovery | brute-force retries |
| Market DB read-only/corrupt | stop affected signals, preserve file and alert | reset DB automatisk |
| Research DB corrupt | isolate research, scanner continues | research skriver market DB |
| LLM unavailable | no-AI mode, bounded error retry | blokkere kritiske signaler |
| Disk full | pause noncritical storage, alert, critical safe stop | slett siste gyldige backup |
| Telegram timeout | durable outbox retry/backoff | dupliser spam |
| Release invalid signature | reject artifact, retain known-good | run unsigned binary |
| Price gap/slippage | invalidate unsafe paper fill | assume perfect stop fill |

## Journal og recovery
Append-only signal events, stable dedup ID, transaction with outbound outbox; process replay from checkpoint/watermark. Network at-least-once semantics with idempotent receiver. Ved restart hent missing historical candles og merk **ikke** simulerte live observations.

## Observability
JSONL rotating logs with request/task/signal/evidence IDs; ring buffer for telemetry, periodic SQLite aggregate, retention and redaction; audit records write-through protected and not casually dropped. Dashboard viser data timestamp og health. No console-secret leakage.

## Rollback
Preserve `current` release pointer and previous known-good code. Database snapshot before schema migrations; test downgrade compatibility or leave fail-safe requiring manual restore, aldri påstå kode-pointer også reverserer data. Release SHA/signature/audit.

## Disaster Recovery drill
1. Detect incident; 2. quarantine corrupt source; 3. show verify backup selection+manifest; 4. restore to isolated temp path; 5. verify referential integrity, signatures, schema; 6. require human GO for destructive swap; 7. start safe mode; 8. reconcile market gaps; 9. generate signed incident report.
